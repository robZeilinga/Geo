﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace GeoAdminServices
{
  public static class LinqExtenssions
  {
    public static IOrderedQueryable<TSource> DynamicQueryableOrderBy<TSource>(this IQueryable<TSource> query, string propertyName, bool desc)
    {
      try
      {
        string methodName = desc ? "OrderByDescending" : "OrderBy";

        var type = typeof(TSource);

        var prop = type.GetProperty(propertyName);

        var parameter = Expression.Parameter(type, "p");

        var propertyAccess = Expression.MakeMemberAccess(parameter, prop);

        var orderByExpression = Expression.Lambda(propertyAccess, parameter);

        var resultExpression = Expression.Call(typeof(Queryable),
                                                methodName,
                                                new Type[] { type, prop.PropertyType },
                                                query.Expression,
                                                Expression.Quote(orderByExpression));

        return (IOrderedQueryable<TSource>)query.Provider.CreateQuery<TSource>(resultExpression);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static IEnumerable<TSource> DynamicEnumerableOrderBy<TSource>(this IQueryable<TSource> query, string propertyName, bool desc)
    {
      try
      {
        string methodName = desc ? "OrderByDescending" : "OrderBy";

        var type = typeof(TSource);

        var prop = type.GetProperty(propertyName);

        var parameter = Expression.Parameter(type, "p");

        var propertyAccess = Expression.MakeMemberAccess(parameter, prop);

        var orderByExpression = Expression.Lambda(propertyAccess, parameter);

        var resultExpression = Expression.Call(typeof(Queryable),
                                                methodName,
                                                new Type[] { type, prop.PropertyType },
                                                query.Expression,
                                                Expression.Quote(orderByExpression));

        return (IEnumerable<TSource>)query.Provider.CreateQuery<TSource>(resultExpression);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

  }
}
