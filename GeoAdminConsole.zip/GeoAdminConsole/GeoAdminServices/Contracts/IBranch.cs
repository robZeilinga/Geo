﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IBranch
  {
    IEnumerable<Centre> getBranches();
    IEnumerable<Province> getProvinces();
    IEnumerable<Region> getRegions();
    BranchViewModel getBranch(double uid);
    void addBranch(BranchViewModel model);
    void updateBranch(BranchViewModel model);
  }
}
