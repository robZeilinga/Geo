﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IAccessPoint
  {
    IEnumerable<AccessPoint> getAccessPoints();
    IEnumerable<Province> getProvinces();
    IEnumerable<Region> getRegions();
    AccessPointViewModel getAccessPoint(double uid);
    void addAccessPoint(AccessPointViewModel model);
    void updateAccessPoint(AccessPointViewModel model);
  }
}
