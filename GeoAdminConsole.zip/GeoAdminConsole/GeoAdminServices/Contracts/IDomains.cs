﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IDomains
  {
    IEnumerable<DomainViewModel> getAllDomains();
    IEnumerable<aspnet_Users> getAllAspnetUsers();
    IEnumerable<aspnet_Roles> getAllAspnetRoles();
    IEnumerable<Log> getAllExceptions();
    aspnet_Users getAspnetUser(string uid);
    aspnet_Roles getAspnetRole(string uid);
    Log getExceptionLog(int uid);
  }
}
