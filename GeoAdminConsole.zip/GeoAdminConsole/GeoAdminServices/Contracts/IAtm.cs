﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IAtm
  {
    IEnumerable<ATM> getATMs();
    IEnumerable<Province> getProvinces();
    IEnumerable<Region> getRegions();
    ATMViewModel getATM(string uid);
    void addATM(ATMViewModel model);
    void updateATM(ATMViewModel model);
  }
}
