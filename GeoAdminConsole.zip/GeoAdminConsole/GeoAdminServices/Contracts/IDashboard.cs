﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IDashboard
  {
    IEnumerable<AccessPointChartViewModel> getAccessPointChartData();
    IEnumerable<ATMProvinceChartViewModel> getATMProvinceChartData();
    IEnumerable<ATMTypeChartViewModel> getATMTypeChartData();
    IEnumerable<ATMTypeChartViewModel> getSAATMTypeChartData();
    IEnumerable<ATMTypeChartViewModel> getROAATMTypeChartData();
    IEnumerable<ATMCentreTypeChartViewModel> getATMCentreTypeChartData();
    IEnumerable<ATMCentreTypeChartViewModel> getSAATMCentreTypeChartData();
    IEnumerable<ATMCentreTypeChartViewModel> getROAATMCentreTypeChartData();
    IEnumerable<BranchChartViewModel> getBranchChartData();
    IEnumerable<PartnerChartViewModel> getPartnerChartData();
    IEnumerable<Province> getProvinces();
  }
}
