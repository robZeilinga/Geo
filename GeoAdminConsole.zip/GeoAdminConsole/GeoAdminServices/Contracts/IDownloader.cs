﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace GeoAdminServices
{
  public interface IDownloader
  {
    MemoryStream DownloadExcelFormat<TEntity>(IEnumerable<TEntity> resultSet, string contentRange, string headerRange, string loadFromCell) where TEntity : class;
    byte[] DownloadCsvFormat<TEntity>(IEnumerable<TEntity> resultSet) where TEntity : class;
  }
}
