﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;

namespace GeoAdminServices
{
  public interface IPartner
  {
    IEnumerable<Partner> getPartners();
    IEnumerable<Province> getProvinces();
    IEnumerable<Region> getRegions();
    PartnerViewModel getPartner(string uid);
    void addPartner(PartnerViewModel model);
    void updatePartner(PartnerViewModel model);
  }
}
