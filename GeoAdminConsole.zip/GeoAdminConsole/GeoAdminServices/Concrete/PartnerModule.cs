﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;
using GeoAdminModels;
using GeoAdminRepository;

namespace GeoAdminServices
{
  public class PartnerModule : IPartner
  {
    #region PartnerModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region PartnerModule Ctor

    public PartnerModule()
    {
      _context = new UnitOfWork();
    }

    public PartnerModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region PartnerModule Methods

    public IEnumerable<Partner> getPartners()
    {
      try
      {
        return _context
              .Repository<Partner>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public IEnumerable<Province> getProvinces()
    {
      try
      {
        return _context
              .Repository<Province>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Region> getRegions()
    {
      try
      {
        return _context
              .Repository<Region>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public PartnerViewModel getPartner(string uid)
    {
      try
      {
        var model = new PartnerViewModel();

        var partner = _context
                    .Repository<Partner>()
                    .FindFirstOrDefault(w => w.PartnerID == uid);

        if (partner != null)
        {
          model.PartnerID = partner.PartnerID;
          model.PartnerName = partner.PartnerName;
          model.Country = partner.Country;
          model.Name = partner.Name;
          model.Address1 = partner.Address1;
          model.Address2 = partner.Address2;
          model.Suburb = partner.Suburb;
          model.Town = partner.Town;
          model.PostCode = partner.PostCode;
          model.Province = partner.Province;
          model.Latitude = partner.Latitude;
          model.Longitude = partner.Longitude;
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Partner with Partner ID {0} does not exist.", uid));
        }

        return model;
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public void addPartner(PartnerViewModel model)
    {
      try
      {
        var partner = new Partner()
        {
          PartnerID = model.PartnerID,
          PartnerName = model.PartnerName,
          Country = model.Country,
          Name = model.Name,
          Address1 = model.Address1,
          Address2 = model.Address2,
          Suburb = model.Suburb,
          Town = model.Town,
          PostCode = model.PostCode,
          Province = model.Province,
          Latitude = model.Latitude,
          Longitude = model.Longitude
        };

        _context.Repository<Partner>().Add(partner);

        _context.Save();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public void updatePartner(PartnerViewModel model)
    {
      try
      {
        var partner = _context
                    .Repository<Partner>()
                    .FindFirstOrDefault(w => w.PartnerID == model.PartnerID);

        if (partner != null)
        {
          partner.PartnerID = model.PartnerID;
          partner.PartnerName = model.PartnerName;
          partner.Country = model.Country;
          partner.Name = model.Name;
          partner.Address1 = model.Address1;
          partner.Address2 = model.Address2;
          partner.Suburb = model.Suburb;
          partner.Town = model.Town;
          partner.PostCode = model.PostCode;
          partner.Province = model.Province;
          partner.Latitude = model.Latitude;
          partner.Longitude = model.Longitude;

          _context.Repository<Partner>().Update(partner);

          _context.Save();
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Partner with Partner ID {0} does not exist.", model.PartnerID));
        }

      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    #endregion

  }
}
