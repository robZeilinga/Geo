﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;
using GeoAdminModels;
using GeoAdminRepository;

namespace GeoAdminServices
{
  public class BranchModule : IBranch
  {
    #region BranchModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region BranchModule Ctor

    public BranchModule()
    {
      _context = new UnitOfWork();
    }

    public BranchModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region BranchModule Methods

    public IEnumerable<Centre> getBranches()
    {
      try
      {
        return _context
              .Repository<Centre>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Region> getRegions()
    {
      try
      {
        return _context
              .Repository<Region>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Province> getProvinces()
    {
      try
      {
        return _context
              .Repository<Province>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public BranchViewModel getBranch(double uid)
    {
      try
      {
        var model = new BranchViewModel();

        var branch = _context
                    .Repository<Centre>()
                    .FindFirstOrDefault(w => w.BranchCode == uid);

        if (branch != null)
        {
          model.BranchCode = branch.BranchCode;
          model.Name = branch.Name;
          model.Type = branch.Type;
          model.ShopNumber = branch.ShopNumber;
          model.BuildingName = branch.BuildingName;
          model.Street = branch.Street;
          model.Suburb = branch.Suburb;
          model.Town = branch.Town;
          model.Province = branch.Province;
          model.Latitude = branch.Latitude;
          model.Longitude = branch.Longitude;
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Branch with Branch Code {0} does not exist.", uid));
        }

        return model;
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void addBranch(BranchViewModel model)
    {
      try
      {
        var branch = new Centre() 
        {
          BranchCode = model.BranchCode,
          Name = model.Name,
          Type = model.Type,
          ShopNumber = model.ShopNumber,
          BuildingName = model.BuildingName,
          Street = model.Street,
          Suburb = model.Suburb,
          Town = model.Town,
          Province = model.Province,
          Latitude = model.Latitude,
          Longitude = model.Longitude
        };

        _context.Repository<Centre>().Add(branch);

        _context.Save();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void updateBranch(BranchViewModel model)
    {
      try
      {
        var branch = _context
                    .Repository<Centre>()
                    .FindFirstOrDefault(w => w.BranchCode == model.BranchCode);

        if (branch != null)
        {
          branch.BranchCode = model.BranchCode;
          branch.Name = model.Name;
          branch.Type = model.Type;
          branch.ShopNumber = model.ShopNumber;
          branch.BuildingName = model.BuildingName;
          branch.Street = model.Street;
          branch.Suburb = model.Suburb;
          branch.Town = model.Town;
          branch.Province = model.Province;
          branch.Latitude = model.Latitude;
          branch.Longitude = model.Longitude;

          _context.Repository<Centre>().Update(branch);

          _context.Save();
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Branch with Branch Code {0} does not exist.", model.BranchCode));
        }
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion
  }
}
