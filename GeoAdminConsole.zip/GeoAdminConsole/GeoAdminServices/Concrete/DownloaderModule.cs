﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Drawing;
using System.Text;
using GeoAdminModels;
using GeoAdminRepository;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Utils;
using CsvHelper;

namespace GeoAdminServices
{
  public class DownloaderModule : IDownloader
  {
    #region DownloaderModule Members

    #endregion

    #region DownloaderModule Ctor

    public DownloaderModule()
    {
    }

    #endregion

    #region DownloaderModule Methods

    public MemoryStream DownloadExcelFormat<TEntity>(IEnumerable<TEntity> resultSet, string contentRange, string headerRange, string loadFromCell) where TEntity : class
    {
      try
      {
        MemoryStream ms = new MemoryStream();

        using (ExcelPackage pck = new ExcelPackage())
        {
          ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Sheet1");

          using (var r = ws.Cells[contentRange])
          {
            r.Style.Numberformat.Format = "@";
            r.Style.Font.SetFromFont(new Font("Calibri", 10, FontStyle.Regular));
          }

          using (var r = ws.Cells[headerRange])
          {
            r.Style.Font.Bold = true;
            r.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
          }

          ws.Cells[loadFromCell].LoadFromCollection(resultSet, true);

          ws.Cells[ws.Dimension.Address].AutoFitColumns();

          pck.SaveAs(ms);

          ms.Position = 0;

          return ms;
        }

      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public byte[] DownloadCsvFormat<TEntity>(IEnumerable<TEntity> resultSet) where TEntity : class
    {
      try
      {
        var ms = new MemoryStream();
        var sWriter = new StreamWriter(ms);
        var csv = new CsvWriter(sWriter);

        csv.Configuration.AutoMap<TEntity>();
        csv.Configuration.Delimiter = "|";
        csv.Configuration.Encoding = Encoding.UTF8;
        csv.Configuration.HasHeaderRecord = true;
        csv.Configuration.IgnoreQuotes = true;
        csv.Configuration.TrimFields = true;

        csv.WriteRecords(resultSet);

        csv.Dispose();

        return ms.ToArray();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion

  }
}
