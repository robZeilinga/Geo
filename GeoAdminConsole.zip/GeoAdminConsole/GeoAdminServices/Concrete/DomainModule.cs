﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;
using GeoAdminRepository;
using System.Data;

namespace GeoAdminServices
{
  public class DomainModule : IDomains
  {
    #region DomainModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region DomainModule Ctor

    public DomainModule()
    {
      _context = new UnitOfWork();
    }

    public DomainModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region DomainModule Methods

    public IEnumerable<DomainViewModel> getAllDomains()
    {
      try
      {
        List<DomainViewModel> lstDomains = new List<DomainViewModel>() 
        {
          new DomainViewModel{ DomainLongName = "adplace.sbicdirectory.com", DomainShortName = "ADCPLACE"},
          new DomainViewModel{ DomainLongName = "branches.sbicdirectory.com", DomainShortName = "BRANCHES"},
          new DomainViewModel{ DomainLongName = "dinersdirectory.com  ", DomainShortName = "DINERS_JHB"},
          new DomainViewModel{ DomainLongName = "dpardirectory.com", DomainShortName = "DPAR"},
          new DomainViewModel{ DomainLongName = "eswitch.sbicdirectory.com", DomainShortName = "ESWITCH"},
          new DomainViewModel{ DomainLongName = "bw.sbicdirectory.com", DomainShortName = "NTBOT"},
          new DomainViewModel{ DomainLongName = "cd.sbicdirectory.com", DomainShortName = "NTDRC"},
          new DomainViewModel{ DomainLongName = "ke.sbicdirectory.com", DomainShortName = "NTKEN"},
          new DomainViewModel{ DomainLongName = "ls.sbicdirectory.com", DomainShortName = "NTLES"},
          new DomainViewModel{ DomainLongName = "ng.sbicdirectory.com", DomainShortName = "NTNIGE"},
          new DomainViewModel{ DomainLongName = "zm.sbicdirectory.com", DomainShortName = "NTZAM"},
          new DomainViewModel{ DomainLongName = "zw.sbicdirectory.com", DomainShortName = "NTZIM"},
          new DomainViewModel{ DomainLongName = "mw.sbicdirectory.com", DomainShortName = "SBGLMWI01"},
          new DomainViewModel{ DomainLongName = "ao.sbicdirectory.com", DomainShortName = "SBICAO01"},
          new DomainViewModel{ DomainLongName = "sbicdirectory.com", DomainShortName = "SBICDIRECTORY"},
          new DomainViewModel{ DomainLongName = "mu.sbicdirectory.com", DomainShortName = "SBICMU01"},
          new DomainViewModel{ DomainLongName = "mz.sbicdirectory.com", DomainShortName = "SBICMZ01"},
          new DomainViewModel{ DomainLongName = "na.sbicdirectory.com", DomainShortName = "SBICNA01"},
          new DomainViewModel{ DomainLongName = "za.sbicdirectory.com", DomainShortName = "SBICZA01"},
          new DomainViewModel{ DomainLongName = "sbintldirectory.com", DomainShortName = "SBINTL"},
          new DomainViewModel{ DomainLongName = "scmbdirectory.com", DomainShortName = "SCMBNT1"},
          new DomainViewModel{ DomainLongName = "stanbic.com", DomainShortName = "STANBIC"},
          new DomainViewModel{ DomainLongName = "gh.sbicdirectory.com", DomainShortName = "STANBICGHAN"},
          new DomainViewModel{ DomainLongName = "sw.sbicdirectory.com", DomainShortName = "STANBICSWA"},
          new DomainViewModel{ DomainLongName = "tz.sbicdirectory.com", DomainShortName = "STANBICTAN"},
          new DomainViewModel{ DomainLongName = "stanlibdirectory.com", DomainShortName = "STANLIB"},
          new DomainViewModel{ DomainLongName = "ug.sbicdirectory.com", DomainShortName = "UGNT"},
        };

        return lstDomains;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public IEnumerable<aspnet_Users> getAllAspnetUsers()
    {
      try
      {
        return _context
              .Repository<aspnet_Users>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public IEnumerable<aspnet_Roles> getAllAspnetRoles()
    {
      try
      {
        return _context
              .Repository<aspnet_Roles>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public IEnumerable<Log> getAllExceptions()
    {
      try
      {
        return _context
              .Repository<Log>()
              .GetAll();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public aspnet_Users getAspnetUser(string uid)
    {
      try
      {
        return _context
              .Repository<aspnet_Users>()
              .FindFirstOrDefault(w => w.UserName == uid);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }

    }

    public aspnet_Roles getAspnetRole(string uid)
    {
      try
      {
        return _context
              .Repository<aspnet_Roles>()
              .FindFirstOrDefault(w => w.RoleName == uid);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public Log getExceptionLog(int uid)
    {
      try
      {
        return _context
              .Repository<Log>()
              .FindFirstOrDefault(w => w.Id == uid);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion

  }
}
