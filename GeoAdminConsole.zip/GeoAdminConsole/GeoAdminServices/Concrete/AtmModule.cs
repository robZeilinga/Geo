﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;
using GeoAdminModels;
using GeoAdminRepository;

namespace GeoAdminServices
{
  public class AtmModule : IAtm
  {
    #region AtmModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region AtmModule Ctor

    public AtmModule()
    {
      _context = new UnitOfWork();
    }

    public AtmModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region  AtmModule Methods

    public IEnumerable<ATM> getATMs()
    {
      try
      {
        return _context
              .Repository<ATM>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Province> getProvinces()
    {
      try
      {
        return _context
              .Repository<Province>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Region> getRegions()
    {
      try
      {
        return _context
              .Repository<Region>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public ATMViewModel getATM(string uid)
    {
      try
      {
        var model = new ATMViewModel();

        var atm = _context
                  .Repository<ATM>()
                  .FindFirstOrDefault(w => w.CICS_ID == uid);

        if (atm != null)
        {
          model.SBSA_PROVINCE = atm.SBSA_PROVINCE;
          model.SBSA_REGION = atm.SBSA_REGION;
          model.SITE_NAME = atm.SITE_NAME;
          model.ATM_NAME = atm.ATM_NAME;
          model.CICS_ID = atm.CICS_ID;
          model.INSTALLATION_DATE = atm.INSTALLATION_DATE;
          model.ADDRESS1 = atm.ADDRESS1;
          model.ADDRESS2 = atm.ADDRESS2;
          model.ADDRESS3 = atm.ADDRESS3;
          model.ADDRESS4 = atm.ADDRESS4;
          model.ADDRESS5 = atm.ADDRESS5;
          model.ADDRESS6 = atm.ADDRESS6;
          model.ADDRESS7 = atm.ADDRESS7;
          model.ATM_OWNERSHIP = atm.ATM_OWNERSHIP;
          model.ATM_TYPE = atm.ATM_TYPE;
          model.ATM_CLASS = atm.ATM_CLASS;
          model.CENTRE_TYPE = atm.CENTRE_TYPE;
          model.CENTRE_NAME = atm.CENTRE_NAME;
          model.CENTRE_NO = atm.CENTRE_NO;
          model.OPEN_TO_PUBLIC = atm.OPEN_TO_PUBLIC;
          model.LONGITUDE = atm.LONGITUDE;
          model.LATITUDE = atm.LATITUDE;
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("ATM with CICS ID {0} does not exist.", uid));
        }

        return model;
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void addATM(ATMViewModel model)
    {
      try
      {
        var atm = new ATM() 
        {
          SBSA_PROVINCE = model.SBSA_PROVINCE,
          SBSA_REGION = model.SBSA_REGION,
          SITE_NAME = model.SITE_NAME,
          ATM_NAME = model.ATM_NAME,
          CICS_ID = model.CICS_ID,
          INSTALLATION_DATE = model.INSTALLATION_DATE,
          ADDRESS1 = model.ADDRESS1,
          ADDRESS2 = model.ADDRESS2,
          ADDRESS3 = model.ADDRESS3,
          ADDRESS4 = model.ADDRESS4,
          ADDRESS5 = model.ADDRESS5,
          ADDRESS6 = model.ADDRESS6,
          ADDRESS7 = model.ADDRESS7,
          ATM_OWNERSHIP = model.ATM_OWNERSHIP,
          ATM_TYPE = model.ATM_TYPE,
          ATM_CLASS = model.ATM_CLASS,
          CENTRE_TYPE = model.CENTRE_TYPE,
          CENTRE_NAME = model.CENTRE_NAME,
          CENTRE_NO = model.CENTRE_NO,
          OPEN_TO_PUBLIC = model.OPEN_TO_PUBLIC,
          LONGITUDE = model.LONGITUDE,
          LATITUDE = model.LATITUDE 
        };

        _context.Repository<ATM>().Add(atm);

        _context.Save();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void updateATM(ATMViewModel model)
    {
      try
      {
        var atm = _context
                 .Repository<ATM>()
                 .FindFirstOrDefault(w => w.CICS_ID == model.CICS_ID);

        if (atm != null)
        {
          atm.SBSA_PROVINCE = model.SBSA_PROVINCE;
          atm.SBSA_REGION = model.SBSA_REGION;
          atm.SITE_NAME = model.SITE_NAME;
          atm.ATM_NAME = model.ATM_NAME;
          atm.CICS_ID = model.CICS_ID;
          atm.INSTALLATION_DATE = model.INSTALLATION_DATE;
          atm.ADDRESS1 = model.ADDRESS1;
          atm.ADDRESS2 = model.ADDRESS2;
          atm.ADDRESS3 = model.ADDRESS3;
          atm.ADDRESS4 = model.ADDRESS4;
          atm.ADDRESS5 = model.ADDRESS5;
          atm.ADDRESS6 = model.ADDRESS6;
          atm.ADDRESS7 = model.ADDRESS7;
          atm.ATM_OWNERSHIP = model.ATM_OWNERSHIP;
          atm.ATM_TYPE = model.ATM_TYPE;
          atm.ATM_CLASS = model.ATM_CLASS;
          atm.CENTRE_TYPE = model.CENTRE_TYPE;
          atm.CENTRE_NAME = model.CENTRE_NAME;
          atm.CENTRE_NO = model.CENTRE_NO;
          atm.OPEN_TO_PUBLIC = model.OPEN_TO_PUBLIC;
          atm.LONGITUDE = model.LONGITUDE;
          atm.LATITUDE = model.LATITUDE;

          _context.Repository<ATM>().Update(atm);

          _context.Save();
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("ATM with CICS ID {0} does not exist.", model.CICS_ID));
        }
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion
  }
}
