﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Entity;
using GeoAdminModels;
using GeoAdminRepository;

namespace GeoAdminServices
{
  public class AccessPointModule : IAccessPoint
  {
    #region AccessPointModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region AccessPointModule Ctor

    public AccessPointModule()
    {
      _context = new UnitOfWork();
    }

    public AccessPointModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region AccessPointModule Methods

    public IEnumerable<AccessPoint> getAccessPoints()
    {
      try
      {
        return _context
              .Repository<AccessPoint>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Province> getProvinces()
    {
      try
      {
        return _context
              .Repository<Province>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Region> getRegions()
    {
      try
      {
        return _context
              .Repository<Region>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public AccessPointViewModel getAccessPoint(double uid)
    {
      try
      {
        var model = new AccessPointViewModel();

        var accessPoints = _context
                          .Repository<AccessPoint>()
                          .FindFirstOrDefault(w => w.MerchantID == uid);

        if (accessPoints != null)
        {
          model.MerchantID = accessPoints.MerchantID;
          model.Name = accessPoints.Name;
          model.Address = accessPoints.Address;
          model.Suburb = accessPoints.Suburb;
          model.Town = accessPoints.Town;
          model.SBSAProvince = accessPoints.SBSAProvince;
          model.Region = accessPoints.Region;
          model.PostalCode = accessPoints.PostalCode;
          model.Province = accessPoints.Province;
          model.Longitude = accessPoints.Longitude;
          model.Latitude = accessPoints.Latitude;
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Access Point with Merchant ID {0} does not exist.", uid));
        }

        return model;
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void addAccessPoint(AccessPointViewModel model)
    {
      try
      {
        var accessPoint = new AccessPoint()
        {
          MerchantID = model.MerchantID,
          Name = model.Name,
          Address = model.Address,
          Suburb = model.Suburb,
          Town = model.Town,
          SBSAProvince = model.SBSAProvince,
          Region = model.Region,
          PostalCode = model.PostalCode,
          Province = model.Province,
          Longitude = model.Longitude,
          Latitude = model.Latitude
        };

        _context.Repository<AccessPoint>().Add(accessPoint);

        _context.Save();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void updateAccessPoint(AccessPointViewModel model)
    {
      try
      {
        var accessPoint = _context
                          .Repository<AccessPoint>()
                          .FindFirstOrDefault(w => w.MerchantID == model.MerchantID);

        if (accessPoint != null)
        {
          accessPoint.MerchantID = model.MerchantID;
          accessPoint.Name = model.Name;
          accessPoint.Address = model.Address;
          accessPoint.Suburb = model.Suburb;
          accessPoint.Town = model.Town;
          accessPoint.SBSAProvince = model.SBSAProvince;
          accessPoint.Region = model.Region;
          accessPoint.PostalCode = model.PostalCode;
          accessPoint.Province = model.Province;
          accessPoint.Longitude = model.Longitude;
          accessPoint.Latitude = model.Latitude;

          _context.Repository<AccessPoint>().Update(accessPoint);

          _context.Save();
        }
        else
        {
          throw new ObjectNotFoundException(string.Format("Access Point with Merchant ID {0} does not exist.", model.MerchantID));
        }

      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion
  }
}
