﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GeoAdminModels;
using GeoAdminRepository;
using System.Data;

namespace GeoAdminServices
{
  public class DashboardModule : IDashboard
  {
    #region DashboardModule Members

    private readonly IUnitOfWork _context;

    #endregion

    #region DashboardModule Ctor

    public DashboardModule()
    {
      _context = new UnitOfWork();
    }

    public DashboardModule(IUnitOfWork context)
    {
      _context = context;
    }

    #endregion

    #region  DashboardModule Methods

    public IEnumerable<AccessPointChartViewModel> getAccessPointChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  ap.Province, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.AccessPoints ap " +
                       "GROUP BY ap.Province";

        return _context
              .Repository<AccessPointChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMProvinceChartViewModel> getATMProvinceChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  a.SBSA_PROVINCE, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "GROUP BY a.SBSA_PROVINCE";

        return _context
              .Repository<ATMProvinceChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMTypeChartViewModel> getATMTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  a.ATM_TYPE, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "GROUP BY a.ATM_TYPE";

        return _context
              .Repository<ATMTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMTypeChartViewModel> getSAATMTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  a.ATM_TYPE, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "WHERE a.SBSA_PROVINCE IN ('KWAZULU NATAL','GAUTENG SOUTH','NORTH WEST','NORTHERN CAPE','WESTERN CAPE','GAUTENG NORTH','EASTERN CAPE','LIMPOPO','MPUMALANGA','FREE STATE','GAUTENG') " +
                       "GROUP BY a.ATM_TYPE";

        return _context
              .Repository<ATMTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMTypeChartViewModel> getROAATMTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  a.ATM_TYPE, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "WHERE NOT a.SBSA_PROVINCE IN ('KWAZULU NATAL','GAUTENG SOUTH','NORTH WEST','NORTHERN CAPE','WESTERN CAPE','GAUTENG NORTH','EASTERN CAPE','LIMPOPO','MPUMALANGA','FREE STATE','GAUTENG') " +
                       "GROUP BY a.ATM_TYPE";

        return _context
              .Repository<ATMTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMCentreTypeChartViewModel> getATMCentreTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  CASE a.CENTRE_TYPE " +
                       "    WHEN NULL THEN 'UNKNOWN' " +
                       "    WHEN '' THEN 'UNKNOWN' " +
                       "    ELSE a.CENTRE_TYPE " +
                       "  END AS [CENTRE_TYPE], " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "GROUP BY a.CENTRE_TYPE";

        return _context
              .Repository<ATMCentreTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMCentreTypeChartViewModel> getSAATMCentreTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  CASE a.CENTRE_TYPE " +
                       "    WHEN NULL THEN 'UNKNOWN' " +
                       "    WHEN '' THEN 'UNKNOWN' " +
                       "    ELSE a.CENTRE_TYPE " +
                       "  END AS [CENTRE_TYPE], " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "WHERE a.SBSA_PROVINCE IN ('KWAZULU NATAL','GAUTENG SOUTH','NORTH WEST','NORTHERN CAPE','WESTERN CAPE','GAUTENG NORTH','EASTERN CAPE','LIMPOPO','MPUMALANGA','FREE STATE','GAUTENG') " +
                       "GROUP BY a.CENTRE_TYPE";

        return _context
              .Repository<ATMCentreTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<ATMCentreTypeChartViewModel> getROAATMCentreTypeChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  CASE a.CENTRE_TYPE " +
                       "    WHEN NULL THEN 'UNKNOWN' " +
                       "    WHEN '' THEN 'UNKNOWN' " +
                       "    ELSE a.CENTRE_TYPE " +
                       "  END AS [CENTRE_TYPE], " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.ATM a " +
                       "WHERE NOT a.SBSA_PROVINCE IN ('KWAZULU NATAL','GAUTENG SOUTH','NORTH WEST','NORTHERN CAPE','WESTERN CAPE','GAUTENG NORTH','EASTERN CAPE','LIMPOPO','MPUMALANGA','FREE STATE','GAUTENG') " +
                       "GROUP BY a.CENTRE_TYPE";

        return _context
              .Repository<ATMCentreTypeChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<BranchChartViewModel> getBranchChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  c.Province, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.Centres c " +
                       "GROUP BY c.Province";

        return _context
              .Repository<BranchChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<PartnerChartViewModel> getPartnerChartData()
    {
      try
      {
        string query = "SELECT " +
                       "  p.Province, " +
                       "  COUNT(*) AS [Count] " +
                       "FROM dbo.Partners p " +
                       "GROUP BY p.Province";

        return _context
              .Repository<PartnerChartViewModel>()
              .ExecuteSQL(query);
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public IEnumerable<Province> getProvinces()
    {
      try
      {
        return _context
              .Repository<Province>()
              .GetAll();
      }
      catch (DataException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion

  }
}
