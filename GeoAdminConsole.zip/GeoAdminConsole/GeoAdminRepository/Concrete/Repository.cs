﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeoAdminRepository
{
  public class Repository<TEntity> : BaseRepository<TEntity> where TEntity : class
  {
    public Repository(DbContext context)
      : base(context)
    {
    }
  }
}
