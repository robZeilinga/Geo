﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GeoAdminData;

namespace GeoAdminRepository
{
  public class UnitOfWork : IUnitOfWork
  {
    #region UnitOfWork Members

    private bool _disposed = false;
    private readonly DbContext _context;
    private Hashtable _repositories;

    #endregion

    #region UnitOfWork Contructors

    public UnitOfWork()
    {
      _context = new GeoContext();
    }

    public UnitOfWork(DbContext context)
    {
      _context = context;
    }

    #endregion

    #region IUnitOfWork Members

    public void Save()
    {
      try
      {
        _context.SaveChanges();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
    
    public IRepository<TEntity> Repository<TEntity>() where TEntity : class
    {
      try
      {
        if (_repositories == null)
          _repositories = new Hashtable();

        var type = typeof(TEntity).Name;

        if (!_repositories.ContainsKey(type))
        {
          var SansRepositoryType = typeof(Repository<>);

          var SansRepositoryInstance = Activator.CreateInstance(SansRepositoryType.MakeGenericType(typeof(TEntity)), _context);

          _repositories.Add(type, SansRepositoryInstance);
        }

        return (IRepository<TEntity>)_repositories[type];
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public void Dispose(bool disposing)
    {
      if (!this._disposed)
      {
        if (disposing)
        {
          _context.Dispose();
        }

        this._disposed = true;
      }
    }

    public void Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }

    #endregion

    #region Finalize

    ~UnitOfWork()
    {
      Dispose(false);
    }

    #endregion
  }
}
