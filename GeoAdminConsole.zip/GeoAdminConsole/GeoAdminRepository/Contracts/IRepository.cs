﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;


namespace GeoAdminRepository
{
  public interface IRepository<TEntity> where TEntity : class
  {
    TEntity FindById(params object[] uniqueIDs);

    TEntity FindFirstOrDefault(Expression<Func<TEntity, bool>> predicate);

    TEntity FindFirstOrDefaultIncluding(Expression<Func<TEntity, bool>> predicate,
                                        List<Expression<Func<TEntity, object>>> navigationProperties = null);

    IEnumerable<TEntity> GetAll(Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null);

    IEnumerable<TEntity> GetAllIncluding(Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                         List<Expression<Func<TEntity, object>>> navigationProperties = null);

    IEnumerable<TEntity> FindAllBy(Expression<Func<TEntity, bool>> predicate,
                                   Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null);

    IEnumerable<TEntity> FindAllByIncluding(Expression<Func<TEntity, bool>> predicate,
                                            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                            List<Expression<Func<TEntity, object>>> navigationProperties = null);

    IEnumerable<TEntity> ExecuteSQL(string execSqlCmd, params SqlParameter[] parameters);

    IEnumerable<TEntity> ExecuteSQL(string execSqlCmd);

    IEnumerable<TEntity> GetPagedList(Expression<Func<TEntity, bool>> predicate = null,
                                      Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                      List<Expression<Func<TEntity, object>>> navigationProperties = null,
                                      int? page = null,
                                      int? pageSize = null);


    RepositoryQuery<TEntity> Query();

    void Add(TEntity entity);

    void Delete(TEntity entity);

    void Delete(params object[] uniqueIDs);

    void Update(TEntity entity);
  }
}
