﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using GeoAdminData;

namespace GeoAdminRepository
{
  public abstract class BaseRepository<TEntity> : IRepository<TEntity> where TEntity : class
  {
    #region BaseRepository Members

    internal DbContext _context;
    internal IDbSet<TEntity> _DbSet;

    #endregion

    #region BaseRepository Constructors

    public BaseRepository(DbContext context)
    {
      _context = context;
      _DbSet = context.Set<TEntity>();
    }

    #endregion

    #region IRepository Members

    public virtual TEntity FindById(params object[] uniqueIDs)
    {
      try
      {
        return _DbSet.Find(uniqueIDs);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual TEntity FindFirstOrDefault(Expression<Func<TEntity, bool>> predicate)
    {
      try
      {
        return _DbSet.Where(predicate).FirstOrDefault();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual TEntity FindFirstOrDefaultIncluding(Expression<Func<TEntity, bool>> predicate,
                                                       List<Expression<Func<TEntity, object>>> navigationProperties = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (navigationProperties != null)
          navigationProperties.ForEach(i => { query = query.Include(i); });

        return query.Where(predicate).FirstOrDefault();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> GetAll(Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (orderBy != null)
          query = orderBy(query);

        return query.ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> GetAllIncluding(Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                                        List<Expression<Func<TEntity, object>>> navigationProperties = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (navigationProperties != null)
          navigationProperties.ForEach(i => { query = query.Include(i); });

        if (orderBy != null)
          query = orderBy(query);

        return query.ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> FindAllBy(Expression<Func<TEntity, bool>> predicate,
                                                  Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (orderBy != null)
          query = orderBy(query);

        return query.Where(predicate).ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> FindAllByIncluding(Expression<Func<TEntity, bool>> predicate,
                                                           Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                                           List<Expression<Func<TEntity, object>>> navigationProperties = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (navigationProperties != null)
          navigationProperties.ForEach(i => { query = query.Include(i); });

        if (orderBy != null)
          query = orderBy(query);

        return query.Where(predicate).ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> ExecuteSQL(string execSqlCmd, params SqlParameter[] parameters)
    {
      try
      {
        return _context
              .Database
              .SqlQuery<TEntity>(execSqlCmd, parameters)
              .ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> ExecuteSQL(string execSqlCmd)
    {
      try
      {
        return _context
              .Database
              .SqlQuery<TEntity>(execSqlCmd)
              .ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual IEnumerable<TEntity> GetPagedList(Expression<Func<TEntity, bool>> predicate = null,
                                                     Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                                     List<Expression<Func<TEntity, object>>> navigationProperties = null,
                                                     int? page = null, int? pageSize = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (navigationProperties != null)
          navigationProperties.ForEach(i => { query = query.Include(i); });

        if (predicate != null)
          query = query.Where(predicate);

        if (orderBy != null)
          query = orderBy(query);

        if (page != null && pageSize != null)
          query = query
                 .Skip((page.Value - 1) * pageSize.Value)
                 .Take(pageSize.Value);

        return query.ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual RepositoryQuery<TEntity> Query()
    {
      try
      {
        var RepositoryFluentHelper = new RepositoryQuery<TEntity>(this);

        return RepositoryFluentHelper;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual void Add(TEntity entity)
    {
      try
      {
        _DbSet.Add(entity);
      }
      catch (DbEntityValidationException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual void Delete(TEntity entity)
    {
      try
      {
        if (!_context.EntityInContext(entity))
          _DbSet.Attach(entity);

        _DbSet.Remove(entity);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual void Delete(params object[] uniqueIDs)
    {
      try
      {
        TEntity entity = _DbSet.Find(uniqueIDs);

        Delete(entity);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public virtual void Update(TEntity entity)
    {
      try
      {
        if (!_context.EntityInContext(entity))
          _DbSet.Attach(entity);

        _context.Entry(entity).State = EntityState.Modified;
      }
      catch (DbEntityValidationException ex)
      {
        throw ex;
      }
      catch (DbUpdateConcurrencyException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    internal IEnumerable<TEntity> Get(Expression<Func<TEntity, bool>> predicate = null,
                                      Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                                      List<Expression<Func<TEntity, object>>> includeProperties = null,
                                      int? page = null,
                                      int? pageSize = null)
    {
      try
      {
        IQueryable<TEntity> query = _DbSet;

        if (includeProperties != null)
          includeProperties.ForEach(i => { query = query.Include(i); });

        if (predicate != null)
          query = query.Where(predicate);

        if (orderBy != null)
          query = orderBy(query);

        if (page != null && pageSize != null)
          query = query
                 .Skip((page.Value - 1) * pageSize.Value)
                 .Take(pageSize.Value);

        return query.ToList();
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    #endregion
  }
}
