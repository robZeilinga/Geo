using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class RegionMap : EntityTypeConfiguration<Region>
    {
        public RegionMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.region1)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Region");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.region1).HasColumnName("region");
        }
    }
}
