using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class AccessPointsOldMap : EntityTypeConfiguration<AccessPointsOld>
    {
        public AccessPointsOldMap()
        {
            // Primary Key
            this.HasKey(t => t.ID);

            // Properties
            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Address)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Suburb)
                .HasMaxLength(255);

            this.Property(t => t.Town)
                .HasMaxLength(255);

            this.Property(t => t.Province)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Batch)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("AccessPointsOld");
            this.Property(t => t.ID).HasColumnName("ID");
            this.Property(t => t.RetailerID).HasColumnName("RetailerID");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.Address).HasColumnName("Address");
            this.Property(t => t.Suburb).HasColumnName("Suburb");
            this.Property(t => t.Town).HasColumnName("Town");
            this.Property(t => t.Province).HasColumnName("Province");
            this.Property(t => t.PostalCode).HasColumnName("PostalCode");
            this.Property(t => t.Latitude).HasColumnName("Latitude");
            this.Property(t => t.Longitude).HasColumnName("Longitude");
            this.Property(t => t.Batch).HasColumnName("Batch");
        }
    }
}
