using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class ATM_ClassMap : EntityTypeConfiguration<ATM_Class>
    {
        public ATM_ClassMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.ATMClass)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("ATM_Class");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ATMClass).HasColumnName("ATMClass");
        }
    }
}
