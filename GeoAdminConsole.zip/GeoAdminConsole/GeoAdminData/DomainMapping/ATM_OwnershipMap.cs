using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class ATM_OwnershipMap : EntityTypeConfiguration<ATM_Ownership>
    {
        public ATM_OwnershipMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.ATMOwnership)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("ATM_Ownership");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ATMOwnership).HasColumnName("ATMOwnership");
        }
    }
}
