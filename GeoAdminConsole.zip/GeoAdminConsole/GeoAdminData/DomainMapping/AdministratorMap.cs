using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class AdministratorMap : EntityTypeConfiguration<Administrator>
    {
        public AdministratorMap()
        {
            // Primary Key
            this.HasKey(t => t.ID);

            // Properties
            this.Property(t => t.UserID)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(150);

            // Table & Column Mappings
            this.ToTable("Administrator");
            this.Property(t => t.ID).HasColumnName("ID");
            this.Property(t => t.UserID).HasColumnName("UserID");
            this.Property(t => t.Name).HasColumnName("Name");
        }
    }
}
