using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class ATM_TypeMap : EntityTypeConfiguration<ATM_Type>
    {
        public ATM_TypeMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.ATMType)
                .IsRequired()
                .HasMaxLength(20);

            this.Property(t => t.Model)
                .IsRequired()
                .HasMaxLength(10);

            // Table & Column Mappings
            this.ToTable("ATM_Type");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.ATMType).HasColumnName("ATMType");
            this.Property(t => t.Model).HasColumnName("Model");
        }
    }
}
