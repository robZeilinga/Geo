using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class AccessPointMap : EntityTypeConfiguration<AccessPoint>
    {
        public AccessPointMap()
        {
            // Primary Key
            this.HasKey(t => t.MerchantID);

            // Properties
            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Address)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Suburb)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Town)
                .HasMaxLength(255);

            this.Property(t => t.SBSAProvince)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Region)
                .HasMaxLength(255);

            this.Property(t => t.Province)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("AccessPoints");
            this.Property(t => t.MerchantID).HasColumnName("MerchantID");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.Address).HasColumnName("Address");
            this.Property(t => t.Suburb).HasColumnName("Suburb");
            this.Property(t => t.Town).HasColumnName("Town");
            this.Property(t => t.SBSAProvince).HasColumnName("SBSAProvince");
            this.Property(t => t.Region).HasColumnName("Region");
            this.Property(t => t.PostalCode).HasColumnName("PostalCode");
            this.Property(t => t.Province).HasColumnName("Province");
            this.Property(t => t.Longitude).HasColumnName("Longitude");
            this.Property(t => t.Latitude).HasColumnName("Latitude");
        }
    }
}
