using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class ATMMap : EntityTypeConfiguration<ATM>
    {
        public ATMMap()
        {
            // Primary Key
            this.HasKey(t => t.CICS_ID);

            // Properties
            this.Property(t => t.SBSA_PROVINCE)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SBSA_REGION)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.SITE_NAME)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.ATM_NAME)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.CICS_ID)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS1)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS2)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS3)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS4)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS5)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS6)
                .HasMaxLength(255);

            this.Property(t => t.ADDRESS7)
                .HasMaxLength(255);

            this.Property(t => t.ATM_OWNERSHIP)
                .HasMaxLength(255);

            this.Property(t => t.ATM_TYPE)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.ATM_CLASS)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.CENTRE_TYPE)
                .HasMaxLength(255);

            this.Property(t => t.CENTRE_NAME)
                .HasMaxLength(255);

            this.Property(t => t.OPEN_TO_PUBLIC)
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("ATM");
            this.Property(t => t.SBSA_PROVINCE).HasColumnName("SBSA_PROVINCE");
            this.Property(t => t.SBSA_REGION).HasColumnName("SBSA_REGION");
            this.Property(t => t.SITE_NAME).HasColumnName("SITE_NAME");
            this.Property(t => t.ATM_NAME).HasColumnName("ATM_NAME");
            this.Property(t => t.CICS_ID).HasColumnName("CICS_ID");
            this.Property(t => t.INSTALLATION_DATE).HasColumnName("INSTALLATION_DATE");
            this.Property(t => t.ADDRESS1).HasColumnName("ADDRESS1");
            this.Property(t => t.ADDRESS2).HasColumnName("ADDRESS2");
            this.Property(t => t.ADDRESS3).HasColumnName("ADDRESS3");
            this.Property(t => t.ADDRESS4).HasColumnName("ADDRESS4");
            this.Property(t => t.ADDRESS5).HasColumnName("ADDRESS5");
            this.Property(t => t.ADDRESS6).HasColumnName("ADDRESS6");
            this.Property(t => t.ADDRESS7).HasColumnName("ADDRESS7");
            this.Property(t => t.ATM_OWNERSHIP).HasColumnName("ATM_OWNERSHIP");
            this.Property(t => t.ATM_TYPE).HasColumnName("ATM_TYPE");
            this.Property(t => t.ATM_CLASS).HasColumnName("ATM_CLASS");
            this.Property(t => t.CENTRE_TYPE).HasColumnName("CENTRE_TYPE");
            this.Property(t => t.CENTRE_NAME).HasColumnName("CENTRE_NAME");
            this.Property(t => t.CENTRE_NO).HasColumnName("CENTRE_NO");
            this.Property(t => t.OPEN_TO_PUBLIC).HasColumnName("OPEN_TO_PUBLIC");
            this.Property(t => t.LONGITUDE).HasColumnName("LONGITUDE");
            this.Property(t => t.LATITUDE).HasColumnName("LATITUDE");
        }
    }
}
