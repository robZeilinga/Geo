using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class Centre_TypeMap : EntityTypeConfiguration<Centre_Type>
    {
        public Centre_TypeMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.CentreType)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("Centre_Type");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.CentreType).HasColumnName("CentreType");
        }
    }
}
