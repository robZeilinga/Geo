using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class POIMap : EntityTypeConfiguration<POI>
    {
        public POIMap()
        {
            // Primary Key
            this.HasKey(t => t.id);

            // Properties
            this.Property(t => t.id)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.attribution)
                .HasMaxLength(150);

            this.Property(t => t.title)
                .IsRequired()
                .HasMaxLength(150);

            this.Property(t => t.imageURL)
                .HasMaxLength(255);

            this.Property(t => t.line4)
                .HasMaxLength(150);

            this.Property(t => t.line3)
                .HasMaxLength(150);

            this.Property(t => t.line2)
                .HasMaxLength(150);

            // Table & Column Mappings
            this.ToTable("POI");
            this.Property(t => t.id).HasColumnName("id");
            this.Property(t => t.attribution).HasColumnName("attribution");
            this.Property(t => t.title).HasColumnName("title");
            this.Property(t => t.lat).HasColumnName("lat");
            this.Property(t => t.lon).HasColumnName("lon");
            this.Property(t => t.imageURL).HasColumnName("imageURL");
            this.Property(t => t.line4).HasColumnName("line4");
            this.Property(t => t.line3).HasColumnName("line3");
            this.Property(t => t.line2).HasColumnName("line2");
            this.Property(t => t.type).HasColumnName("type");
            this.Property(t => t.dimension).HasColumnName("dimension");
            this.Property(t => t.alt).HasColumnName("alt");
            this.Property(t => t.relativeAlt).HasColumnName("relativeAlt");
            this.Property(t => t.distance).HasColumnName("distance");
            this.Property(t => t.inFocus).HasColumnName("inFocus");
            this.Property(t => t.doNotIndex).HasColumnName("doNotIndex");
            this.Property(t => t.showSmallBiw).HasColumnName("showSmallBiw");
            this.Property(t => t.showBiwOnClick).HasColumnName("showBiwOnClick");
        }
    }
}
