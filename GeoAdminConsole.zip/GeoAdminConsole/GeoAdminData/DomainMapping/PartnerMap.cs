using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class PartnerMap : EntityTypeConfiguration<Partner>
    {
        public PartnerMap()
        {
            // Primary Key
            this.HasKey(t => t.PartnerID);

            // Properties
            this.Property(t => t.PartnerID)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.PartnerName)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Country)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Address1)
                .HasMaxLength(255);

            this.Property(t => t.Address2)
                .HasMaxLength(255);

            this.Property(t => t.Suburb)
                .HasMaxLength(255);

            this.Property(t => t.Town)
                .HasMaxLength(255);

            this.Property(t => t.Province)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("Partners");
            this.Property(t => t.PartnerID).HasColumnName("PartnerID");
            this.Property(t => t.PartnerName).HasColumnName("PartnerName");
            this.Property(t => t.Country).HasColumnName("Country");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.Address1).HasColumnName("Address1");
            this.Property(t => t.Address2).HasColumnName("Address2");
            this.Property(t => t.Suburb).HasColumnName("Suburb");
            this.Property(t => t.Town).HasColumnName("Town");
            this.Property(t => t.PostCode).HasColumnName("PostCode");
            this.Property(t => t.Province).HasColumnName("Province");
            this.Property(t => t.Latitude).HasColumnName("Latitude");
            this.Property(t => t.Longitude).HasColumnName("Longitude");
        }
    }
}
