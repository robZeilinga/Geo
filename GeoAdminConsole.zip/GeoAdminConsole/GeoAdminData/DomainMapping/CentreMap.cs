using System.ComponentModel.DataAnnotations;
using System.Data.Entity.ModelConfiguration;
using GeoAdminModels;

namespace GeoAdminData
{
    public class CentreMap : EntityTypeConfiguration<Centre>
    {
        public CentreMap()
        {
            // Primary Key
            this.HasKey(t => t.BranchCode);

            // Properties
            this.Property(t => t.Name)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.Type)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.ShopNumber)
                .HasMaxLength(255);

            this.Property(t => t.BuildingName)
                .HasMaxLength(255);

            this.Property(t => t.Street)
                .HasMaxLength(255);

            this.Property(t => t.Suburb)
                .HasMaxLength(255);

            this.Property(t => t.Town)
                .HasMaxLength(255);

            this.Property(t => t.Province)
                .IsRequired()
                .HasMaxLength(255);

            // Table & Column Mappings
            this.ToTable("Centres");
            this.Property(t => t.BranchCode).HasColumnName("BranchCode");
            this.Property(t => t.Name).HasColumnName("Name");
            this.Property(t => t.Type).HasColumnName("Type");
            this.Property(t => t.ShopNumber).HasColumnName("ShopNumber");
            this.Property(t => t.BuildingName).HasColumnName("BuildingName");
            this.Property(t => t.Street).HasColumnName("Street");
            this.Property(t => t.Suburb).HasColumnName("Suburb");
            this.Property(t => t.Town).HasColumnName("Town");
            this.Property(t => t.Province).HasColumnName("Province");
            this.Property(t => t.Latitude).HasColumnName("Latitude");
            this.Property(t => t.Longitude).HasColumnName("Longitude");
        }
    }
}
