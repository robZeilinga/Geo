﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace GeoAdminData
{
  public static class DbContextExtension
  {
    public static bool EntityInContext<TContext, TEntity>(this TContext context, TEntity entity)
      where TContext : DbContext
      where TEntity : class
    {
      return context.Set<TEntity>().Local.Any(e => e == entity);
    }
  }
}
