﻿﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using GeoAdminModels;
using GeoAdminServices;
using System.Security.Principal;
using Newtonsoft.Json;
using DataTables.Mvc.Net4;
using System.Text;
using System.Net;

namespace GeoAdminWeb.Controllers
{
  [Authorize(Roles = "Admins")]
  [CustomHandleError]
  public class AccountController : Controller
  {
    private IDomains _domain;

    public AccountController(IDomains domain)
    {
      _domain = domain;
    }

    public ActionResult Index()
    {
      return View();
    }

    [AllowAnonymous]
    public ActionResult LogOn()
    {
      var model = new LogOnModel();

      ViewBag.Domains = _domain.getAllDomains();

      return View(model);
    }

    [HttpPost]
    [AllowAnonymous]
    public ActionResult LogOn(LogOnModel model)
    {
      if (ModelState.IsValid)
      {
        string domain = "SBICZA01";
        string domainController = "";

        if (!string.IsNullOrEmpty(model.DomainName))
        {
          domain = _domain.getAllDomains().First(w => w.DomainLongName == model.DomainName).DomainShortName;
          domainController = model.DomainName;
        }
        string domainAndUser = string.Concat(domain, @"\", model.UserName);

        if (ActiveDirectoryHelper.AuthenticateUser(domain, model.UserName, model.Password, domainController))
        {

          var userRoles = Roles.Provider.GetRolesForUser(domainAndUser);

          if (userRoles.Any())
          {
            FormsAuthentication.SetAuthCookie(domainAndUser, true);

            var activeUser = new LogOnModel() 
            {
              DomainName = domain,
              UserName = model.UserName,
              Password = model.Password
            };

            Session["userContext"] = activeUser;

            return RedirectToAction("Index", "Home");
          }
          else
          {
            ModelState.AddModelError("", "You are not registered as a user of this site.");
          }

        }
        else
        {
          ModelState.AddModelError("", "The user name or password provided is incorrect.");
        }

      }

      ViewBag.Domains = _domain.getAllDomains();

      // If we got this far, something failed, redisplay form
      return View(model);
    }

    public ActionResult LogOff()
    {
      FormsAuthentication.SignOut();

      return RedirectToAction("LogOn");
    }

    public ActionResult Register()
    {
      var model = new RegisterModel();

      ViewBag.UserRoles = new SelectList(Roles.Provider.GetAllRoles());

      ViewBag.Domains = new SelectList(_domain.getAllDomains(), "DomainLongName", "DomainShortName");

      return View(model);
    }

    [HttpPost]
    public ActionResult Register(RegisterModel model)
    {
      if (ModelState.IsValid)
      {
        string domain = _domain.getAllDomains().First(w => w.DomainLongName == model.DomainName).DomainShortName;
        string domainAndUser = string.Concat(domain, @"\", model.UserName);

        LogOnModel activeUser = Session["userContext"] as LogOnModel;

        var userValid = ActiveDirectoryHelper.SearchActiveDirectoryUsers(model.DomainName, activeUser.UserName, activeUser.Password, model.UserName);

        if (userValid.Count == 1)
        {
          var userRoles = Roles.Provider.GetRolesForUser(domainAndUser);

          string[] userName = { domainAndUser };
          string[] userRole = { model.RoleName };

          if (!userRoles.Any())
          {
            Roles.Provider.AddUsersToRoles(userName, userRole);

            return RedirectToAction("Index");
          }
          else
          {
            ModelState.AddModelError("", string.Format("User is already assigned to role {0}. Users are not allowed in multiple roles", userRoles.First()));
          }
        }
        else if (userValid.Count > 1)
        {
          ModelState.AddModelError("", "More than 1 user was found with similiar employee or contractor's number, please use search function to select correct user.");
        }
        else
        {
          ModelState.AddModelError("", "The user name is not a valid employee or contractor's number or the user does not exists");
        }
      }

      ViewBag.UserRoles = new SelectList(Roles.Provider.GetAllRoles());

      ViewBag.Domains = new SelectList(_domain.getAllDomains(), "DomainLongName", "DomainShortName");

      // If we got this far, something failed, redisplay form
      return View(model);
    }

    public ActionResult RolesList()
    {
      List<RoleViewModel> lstRoles = null;

      if (Roles.Provider.GetAllRoles().Any())
      {
        lstRoles = new List<RoleViewModel>();

        foreach (var role in Roles.Provider.GetAllRoles())
        {
          RoleViewModel model = new RoleViewModel()
          {
            RoleName = role
          };

          lstRoles.Add(model);
        }

      }

      return View(lstRoles);
    }

    public ActionResult ExceptionsList()
    {
      return View();
    }

    public ActionResult ExceptionDetail(int uid)
    {
      var model = _domain.getExceptionLog(uid);

      return View(model);
    }

    public ActionResult AddApplicationRole()
    {
      var model = new RoleViewModel();

      return View(model);
    }

    [HttpPost]
    public ActionResult AddApplicationRole(RoleViewModel model)
    {
      if (ModelState.IsValid)
      {
        if (!Roles.Provider.RoleExists(model.RoleName))
        {
          Roles.Provider.CreateRole(model.RoleName);

          return RedirectToAction("RolesList");
        }
        else
        {
          ModelState.AddModelError("", "Role already exists.");
        }
      }

      return View(model);
    }

    public JsonResult DeleteApplicationRole(string uid)
    {
      string message = "";

      try
      {
        if (Roles.Provider.RoleExists(uid))
        {
          Roles.Provider.DeleteRole(uid, true);

          Response.StatusCode = (int)HttpStatusCode.OK;
          message = string.Format("Role {0} successfully deleted.", uid);
        }
        else
        {
          Response.StatusCode = (int)HttpStatusCode.InternalServerError;
          message = string.Format("Role {0} couldn't be deleted or doesn't exist.", uid);
        }

        return Json(new { SuccessMessage = message }, "application/json", JsonRequestBehavior.AllowGet);
      }
      catch (Exception ex)
      {
        Response.StatusCode = (int)HttpStatusCode.InternalServerError;
        return Json(new { SuccessMessage = ex.Message }, "application/json", JsonRequestBehavior.AllowGet);
      }

    }

    public ActionResult AddUserToRole(string uid)
    {
      string userAndDomain = uid.Replace('_', '\\');

      string userRole = !string.IsNullOrEmpty(Roles.Provider.GetRolesForUser(userAndDomain).FirstOrDefault()) ? Roles.Provider.GetRolesForUser(userAndDomain).FirstOrDefault() : "";

      var model = new UserRoleViewModel()
      {
        UserName = userAndDomain,
        RoleName = userRole
      };

      ViewBag.UserRoles = new SelectList(Roles.Provider.GetAllRoles(), userRole);

      return View(model);
    }

    [HttpPost]
    public ActionResult AddUserToRole(UserRoleViewModel model)
    {
      if (ModelState.IsValid)
      {
        var userRoles = Roles.Provider.GetRolesForUser(model.UserName);

        string[] userName = { model.UserName };
        string[] userRole = { model.RoleName };

        if (!userRoles.Any())
        {
          Roles.Provider.AddUsersToRoles(userName, userRole);

          return RedirectToAction("Index");
        }
        else
        {
          Roles.Provider.RemoveUsersFromRoles(userName, userRole);

          Roles.Provider.AddUsersToRoles(userName, userRole);

          return RedirectToAction("Index");
        }

      }

      ViewBag.UserRoles = new SelectList(Roles.Provider.GetAllRoles(), model.RoleName);

      return View(model);
    }

    public JsonResult RemoveUserFromRole(string uid)
    {
      string message = "";

      try
      {
        string userAndDomain = uid.Replace('_', '\\');
        string[] userRoles = Roles.Provider.GetRolesForUser(userAndDomain);
        string[] userName = { userAndDomain };

        if (Roles.Provider.IsUserInRole(userAndDomain, userRoles[0]))
        {
          Roles.Provider.RemoveUsersFromRoles(userName, userRoles);

          Response.StatusCode = (int)HttpStatusCode.OK;
          message = string.Format("User {0} successfully removed from role {1}", userAndDomain, userRoles[0]);
        }
        else
        {
          Response.StatusCode = (int)HttpStatusCode.InternalServerError;
          message = string.Format("User {0} couldn't be removed from role {1} or the user or role doesn't exist.", userAndDomain, userRoles[0]);
        }

        return Json(new { SuccessMessage = message }, "application/json", JsonRequestBehavior.AllowGet);

      }
      catch (Exception ex)
      {
        Response.StatusCode = (int)HttpStatusCode.InternalServerError;
        return Json(new { SuccessMessage = ex.Message }, "application/json", JsonRequestBehavior.AllowGet);
      }

    }

    public JsonResult GetApplicationUsers([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<ADUserViewModel> rawData = this.GetUsers();
      IEnumerable<ADUserViewModel> searchData = null;
      IEnumerable<ADUserViewModel> orderData = null;
      IEnumerable<ADUserViewModel> result = null;

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          string searchString = requestModel.Search.Value;

          searchData = rawData
                      .Where(w => w.UserName.ToLower().Contains(searchString)
                      || (w.DisplayName != null && w.DisplayName.ToLower().Contains(searchString))
                      || (w.Mail != null && w.Mail.ToLower().Contains(searchString))
                      || (w.SamAccountName != null && w.SamAccountName.ToLower().Contains(searchString))
                      || (w.C != null && w.C.ToLower().Contains(searchString)));
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    public JsonResult SearchActiveDirectory(ADSearchUserViewModel model)
    {
      List<ADUserViewModel> result = null;

      LogOnModel activeUser = Session["userContext"] as LogOnModel;

      if (!string.IsNullOrEmpty(model.SearchValue))
      {
        switch (model.SearchField.ToLower())
        {
          case "employee number":
            result = ActiveDirectoryHelper.SearchActiveDirectoryUsers(activeUser.DomainName, activeUser.UserName, activeUser.Password, model.SearchValue, null, null);
            break;
          case "display name":
            result = ActiveDirectoryHelper.SearchActiveDirectoryUsers(activeUser.DomainName, activeUser.UserName, activeUser.Password, null, model.SearchValue, null);
            break;
          case "email":
            result = ActiveDirectoryHelper.SearchActiveDirectoryUsers(activeUser.DomainName, activeUser.UserName, activeUser.Password, null, null, model.SearchValue);
            break;
        }
      }

      return Json(new { users = result }, "application/json", JsonRequestBehavior.AllowGet);
    }

    public JsonResult GetApplicationExceptions([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<Log> rawData = _domain.getAllExceptions();
      IEnumerable<Log> searchData = null;
      IEnumerable<Log> orderData = null;
      IEnumerable<Log> result = null;

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          DateTime searchDate = new DateTime();

          int numSearch = 0;

          string searchString = requestModel.Search.Value;

          if (DateTime.TryParse(searchString, out searchDate))
          {
            string dateString = string.Format("{0:yyyyMMdd}", searchDate);

            searchData = rawData.Where(w => string.Format("{0:yyyyMMdd}", w.Date).Contains(dateString));
          }
          else if (int.TryParse(searchString, out numSearch))
          {
            searchData = rawData
                        .Where(w => w.Id == numSearch
                        || w.Id.ToString().ToLower().Contains(searchString));
          }
          else
          {
            searchData = rawData
                        .Where(w => w.Thread.ToLower().Contains(searchString)
                        || (w.Level != null && w.Level.ToLower().Contains(searchString))
                        || (w.Logger != null && w.Logger.ToLower().Contains(searchString))
                        || (w.Message != null && w.Message.ToLower().Contains(searchString)));
          }
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    private List<ADUserViewModel> GetUsers()
    {
      List<ADUserViewModel> lstUsers = new List<ADUserViewModel>();

      var users = _domain.getAllAspnetUsers();

      if (users.Any())
      {
        LogOnModel activeUser = Session["userContext"] as LogOnModel;

        foreach (var u in users)
        {
          string[] userAndDomain = u.UserName.Split('\\');
          string domainController = _domain
                                   .getAllDomains()
                                   .Where(w => w.DomainShortName == userAndDomain[0])
                                   .First()
                                   .DomainLongName;

          ADUserViewModel model = new ADUserViewModel();

          if (activeUser != null)
          {
            model = ActiveDirectoryHelper.ADLoadUserInfo(activeUser.DomainName, activeUser.UserName, activeUser.Password, userAndDomain[1]);
          }
          else
          {
            model = null;
          }

          if (model != null)
          {
            model.UserName = u.UserName;

            var userRoles = Roles.Provider.GetRolesForUser(u.UserName);

            if (userRoles.Any())
              model.RoleName = userRoles.First();
            else
              model.RoleName = "";

            lstUsers.Add(model);
          }

        }
      }

      return lstUsers;
    }

  }
}
