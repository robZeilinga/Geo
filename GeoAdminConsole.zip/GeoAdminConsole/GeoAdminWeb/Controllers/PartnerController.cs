﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GeoAdminServices;
using GeoAdminModels;
using Newtonsoft.Json;
using DataTables.Mvc.Net4;
using System.Text;
using System.IO;

namespace GeoAdminWeb.Controllers
{
  [Authorize]
  [CustomHandleError]
  public class PartnerController : Controller
  {
    private IPartner _partner;
    private IDownloader _downloader;

    public PartnerController(IPartner partner, IDownloader downloader)
    {
      _partner = partner;
      _downloader = downloader;
    }

    public ActionResult Index()
    {
      return View();
    }

    public ActionResult AddPartner()
    {
      var model = new PartnerViewModel();

      ViewBag.Provinces = new SelectList(_partner.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    [HttpPost]
    public ActionResult AddPartner(PartnerViewModel model)
    {
      if (ModelState.IsValid)
      {
        _partner.addPartner(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_partner.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    public ActionResult EditPartner(string uid)
    {
      var model = _partner.getPartner(uid);

      ViewBag.Provinces = new SelectList(_partner.getProvinces(), "Province1", "Province1", model.Province.ToUpper());

      return View(model);
    }

    [HttpPost]
    public ActionResult EditPartner(PartnerViewModel model)
    {
      if (ModelState.IsValid)
      {
        _partner.updatePartner(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_partner.getProvinces(), "Province1", "Province1", model.Province.ToUpper());

      return View(model);
    }

    public ActionResult PartnerDetail(string uid)
    {
      var model = _partner.getPartner(uid);

      return View(model);
    }

    public JsonResult GetPartners([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<Partner> rawData = null;
      IEnumerable<Partner> searchData = null;
      IEnumerable<Partner> orderData = null;
      IEnumerable<Partner> result = null;

      rawData = _partner.getPartners();

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          double numSearch = 0;

          string searchString = requestModel.Search.Value;

          if (double.TryParse(searchString, out numSearch))
          {
            searchData = rawData
                        .Where(w => w.PostCode == numSearch
                        || w.Longitude.ToString().ToLower().Contains(searchString)
                        || w.Latitude.ToString().ToLower().Contains(searchString));
          }
          else
          {
            searchData = rawData
                        .Where(w => w.PartnerID.ToLower().Contains(searchString)
                        || w.PartnerName.ToLower().Contains(searchString)
                        || w.Country.ToLower().Contains(searchString)
                        || w.Name.ToLower().Contains(searchString)
                        || (w.Address1 != null && w.Address1.ToLower().Contains(searchString))
                        || (w.Address2 != null && w.Address2.ToLower().Contains(searchString))
                        || (w.Suburb != null && w.Suburb.ToLower().Contains(searchString))
                        || (w.Town != null && w.Town.ToLower().Contains(searchString))
                        || w.Province.ToLower().Contains(searchString));
          }
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    public FileResult PartnerExcelDownload()
    {
      var fileName = string.Format("Partner List - {0:dd MMM yy}.xlsx", DateTime.Now);
      var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

      IEnumerable<Partner> resultSet = null;

      resultSet = _partner.getPartners();

      MemoryStream ms = _downloader.DownloadExcelFormat(resultSet, "A:XFD", "A1:XFD1", "A1");

      return File(ms, contentType, fileName);
    }

    public FileResult PartnerCsvDownload()
    {
      var fileName = string.Format("Partner List - {0:dd MMM yy}.csv", DateTime.Now);
      var contentType = "text/csv";

      IEnumerable<Partner> resultSet = null;

      resultSet = _partner.getPartners();

      byte[] ms = _downloader.DownloadCsvFormat(resultSet);

      return File(ms, contentType, fileName);
    }

  }
}
