﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GeoAdminServices;
using GeoAdminModels;
using Newtonsoft.Json;
using DataTables.Mvc.Net4;
using System.Text;
using System.Web.Security;
using System.IO;

namespace GeoAdminWeb.Controllers
{
  [Authorize]
  [CustomHandleError]
  public class ATMController : Controller
  {
    private IAtm _atm;
    private IDownloader _downloader;

    public ATMController(IAtm atm,IDownloader downloader)
    {
      _atm = atm;
      _downloader = downloader;
    }

    public ActionResult Index()
    {
      return View();
    }

    public ActionResult AddATM()
    {
      var model = new ATMViewModel();

      ViewBag.Provinces = new SelectList(_atm.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    [HttpPost]
    public ActionResult AddATM(ATMViewModel model)
    {
      if (ModelState.IsValid)
      {
        _atm.addATM(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_atm.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    public ActionResult EditATM(string uid)
    {
      var model = _atm.getATM(uid);

      ViewBag.Provinces = new SelectList(_atm.getProvinces(), "Province1", "Province1",model.SBSA_PROVINCE);

      return View(model);
    }

    [HttpPost]
    public ActionResult EditATM(ATMViewModel model)
    {
      if (ModelState.IsValid)
      {
        _atm.updateATM(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_atm.getProvinces(), "Province1", "Province1", model.SBSA_PROVINCE);

      return View(model);
    }

    public ActionResult ATMDetail(string uid)
    {
      var model = _atm.getATM(uid);

      return View(model);
    }

    public JsonResult GetATMs([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<ATM> rawData = null;
      IEnumerable<ATM> searchData = null;
      IEnumerable<ATM> orderData = null;
      IEnumerable<ATM> result = null;

      var saProvince = _atm.getProvinces();

      if (User.IsInRole("Admins"))
      {
        rawData = _atm.getATMs();
      }
      else if (User.IsInRole("ROAUser"))
      {
        rawData = _atm
                  .getATMs()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));

      }
      else if (User.IsInRole("SAUser"))
      {
        rawData = _atm
                 .getATMs()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));
      }

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          double numSearch = 0;

          string searchString = requestModel.Search.Value;

          if (double.TryParse(searchString, out numSearch))
          {
            searchData = rawData
                        .Where(w => w.CICS_ID.ToLower().Contains(searchString)
                        || w.INSTALLATION_DATE.ToString().ToLower().Contains(searchString)
                        || w.CENTRE_NO.ToString().ToLower().Contains(searchString)
                        || w.LONGITUDE.ToString().ToLower().Contains(searchString)
                        || w.LATITUDE.ToString().ToLower().Contains(searchString));
          }
          else
          {
            searchData = rawData
                        .Where(w => w.SBSA_PROVINCE.ToLower().Contains(searchString)
                        || w.SBSA_REGION.ToLower().Contains(searchString)
                        || w.SITE_NAME.ToLower().Contains(searchString)
                        || w.ATM_NAME.ToLower().Contains(searchString)
                        || w.CICS_ID.ToLower().Contains(searchString)
                        || (w.ADDRESS1 != null && w.ADDRESS1.ToLower().Contains(searchString))
                        || (w.ADDRESS2 != null && w.ADDRESS2.ToLower().Contains(searchString))
                        || (w.ADDRESS3 != null && w.ADDRESS3.ToLower().Contains(searchString))
                        || (w.ADDRESS4 != null && w.ADDRESS4.ToLower().Contains(searchString))
                        || (w.ADDRESS5 != null && w.ADDRESS5.ToLower().Contains(searchString))
                        || (w.ADDRESS6 != null && w.ADDRESS6.ToLower().Contains(searchString))
                        || (w.ADDRESS7 != null && w.ADDRESS7.ToLower().Contains(searchString))
                        || (w.ATM_OWNERSHIP != null && w.ATM_OWNERSHIP.ToLower().Contains(searchString))
                        || (w.ATM_TYPE != null && w.ATM_TYPE.ToLower().Contains(searchString))
                        || (w.ATM_CLASS != null && w.ATM_CLASS.ToLower().Contains(searchString))
                        || (w.CENTRE_TYPE != null && w.CENTRE_TYPE.ToLower().Contains(searchString))
                        || (w.CENTRE_NAME != null && w.CENTRE_NAME.ToLower().Contains(searchString))
                        || (w.OPEN_TO_PUBLIC != null && w.OPEN_TO_PUBLIC.ToLower().Contains(searchString)));
          }
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    public FileResult ATMExcelDownload()
    {
      var fileName = string.Format("ATMs List - {0:dd MMM yy}.xlsx", DateTime.Now);
      var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

      IEnumerable<ATM> resultSet = null;

      var saProvince = _atm.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _atm.getATMs();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _atm
                  .getATMs()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _atm
                 .getATMs()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));
      }

      MemoryStream ms = _downloader.DownloadExcelFormat(resultSet, "A:XFD", "A1:XFD1", "A1");

      return File(ms, contentType, fileName);
    }

    public FileResult ATMCsvDownload()
    {
      var fileName = string.Format("ATMs List - {0:dd MMM yy}.csv", DateTime.Now);
      var contentType = "text/csv";

      IEnumerable<ATM> resultSet = null;

      var saProvince = _atm.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _atm.getATMs();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _atm
                  .getATMs()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _atm
                 .getATMs()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));
      }

      byte[] ms = _downloader.DownloadCsvFormat(resultSet);

      return File(ms, contentType, fileName);
    }

  }
}
