﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GeoAdminServices;
using GeoAdminModels;
using Newtonsoft.Json;
using DataTables.Mvc.Net4;
using System.Text;
using System.IO;

namespace GeoAdminWeb.Controllers
{
  [Authorize]
  [CustomHandleError]
  public class BranchController : Controller
  {
    private IBranch _branch;
    private IDownloader _downloader;

    public BranchController(IBranch branch,IDownloader downloader)
    {
      _branch = branch;
      _downloader = downloader;
    }

    public ActionResult Index()
    {
      return View();
    }

    public ActionResult AddBranch()
    {
      var model = new BranchViewModel();

      ViewBag.Provinces = new SelectList(_branch.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    [HttpPost]
    public ActionResult AddBranch(BranchViewModel model)
    {
      if (ModelState.IsValid)
      {
        _branch.addBranch(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_branch.getProvinces(), "Province1", "Province1");

      return View(model);
    }

    public ActionResult EditBranch(double uid)
    {
      var model = _branch.getBranch(uid);

      ViewBag.Provinces = new SelectList(_branch.getProvinces(), "Province1", "Province1",model.Province.ToUpper());

      return View(model);
    }

    [HttpPost]
    public ActionResult EditBranch(BranchViewModel model)
    {
      if (ModelState.IsValid)
      {
        _branch.updateBranch(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_branch.getProvinces(), "Province1", "Province1",model.Province.ToUpper());

      return View(model);
    }

    public ActionResult BranchDetail(double uid)
    {
      var model = _branch.getBranch(uid);

      return View(model);
    }

    public JsonResult GetBranches([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<Centre> rawData = null;
      IEnumerable<Centre> searchData = null;
      IEnumerable<Centre> orderData = null;
      IEnumerable<Centre> result = null;

      var saProvince = _branch.getProvinces();

      if (User.IsInRole("Admins"))
      {
        rawData = _branch.getBranches();
      }
      else if (User.IsInRole("ROAUser"))
      {
        rawData = _branch
                  .getBranches()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        rawData = _branch
                 .getBranches()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          double numSearch = 0;

          string searchString = requestModel.Search.Value;

          if (double.TryParse(searchString, out numSearch))
          {
            searchData = rawData
                        .Where(w => w.BranchCode.ToString().ToLower().Contains(searchString)
                        || w.Latitude.ToString().ToLower().Contains(searchString)
                        || w.Longitude.ToString().ToLower().Contains(searchString));
          }
          else
          {
            searchData = rawData
                        .Where(w => w.Name.ToLower().Contains(searchString)
                        || w.Type.ToLower().Contains(searchString)
                        || (w.ShopNumber != null && w.ShopNumber.ToLower().Contains(searchString))
                        || (w.BuildingName != null && w.BuildingName.ToLower().Contains(searchString))
                        || (w.Street != null && w.Street.ToLower().Contains(searchString))
                        || (w.Suburb != null && w.Suburb.ToLower().Contains(searchString))
                        || (w.Town != null && w.Town.ToLower().Contains(searchString))
                        || (w.Province != null && w.Province.ToLower().Contains(searchString)));
          }
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    public FileResult BranchExcelDownload()
    {
      var fileName = string.Format("Branches List - {0:dd MMM yy}.xlsx", DateTime.Now);
      var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

      IEnumerable<Centre> resultSet = null;

      var saProvince = _branch.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _branch.getBranches();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _branch
                  .getBranches()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _branch
                 .getBranches()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      MemoryStream ms = _downloader.DownloadExcelFormat(resultSet, "A:XFD", "A1:XFD1", "A1");

      return File(ms, contentType, fileName);
    }

    public FileResult BranchCsvDownload()
    {
      var fileName = string.Format("Branches List - {0:dd MMM yy}.csv", DateTime.Now);
      var contentType = "text/csv";

      IEnumerable<Centre> resultSet = null;

      var saProvince = _branch.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _branch.getBranches();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _branch
                  .getBranches()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _branch
                 .getBranches()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      byte[] ms = _downloader.DownloadCsvFormat(resultSet);

      return File(ms, contentType, fileName);
    }

  }
}
