﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GeoAdminServices;
using GeoAdminModels;
using Newtonsoft.Json;
using DataTables.Mvc.Net4;
using System.Text;
using System.IO;

namespace GeoAdminWeb.Controllers
{
  [Authorize]
  [CustomHandleError]
  public class AccessPointController : Controller
  {
    private IAccessPoint _accessPoint;
    private IDownloader _downloader;

    public AccessPointController(IAccessPoint accessPoint,IDownloader downloader)
    {
      _accessPoint = accessPoint;
      _downloader = downloader;
    }

    public ActionResult Index()
    {
      return View();
    }

    public ActionResult AddAccessPoint()
    {
      var model = new AccessPointViewModel();

      ViewBag.Provinces = new SelectList(_accessPoint.getProvinces(), "Province1", "Province1");
      ViewBag.Regions = new SelectList(_accessPoint.getRegions(), "region1", "region1");

      return View(model);
    }

    [HttpPost]
    public ActionResult AddAccessPoint(AccessPointViewModel model)
    {
      if (ModelState.IsValid)
      {
        _accessPoint.addAccessPoint(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_accessPoint.getProvinces(), "Province1", "Province1");
      ViewBag.Regions = new SelectList(_accessPoint.getRegions(), "region1", "region1");

      return View(model);
    }

    public ActionResult EditAccessPoint(double uid)
    {
      var model = _accessPoint.getAccessPoint(uid);

      ViewBag.Provinces = new SelectList(_accessPoint.getProvinces(), "Province1", "Province1",model.Province.ToUpper());
      ViewBag.Regions = new SelectList(_accessPoint.getRegions(), "region1", "region1",model.Region.ToUpper());

      return View(model);
    }

    [HttpPost]
    public ActionResult EditAccessPoint(AccessPointViewModel model)
    {
      if (ModelState.IsValid)
      {
        _accessPoint.updateAccessPoint(model);

        return RedirectToAction("Index");
      }

      ViewBag.Provinces = new SelectList(_accessPoint.getProvinces(), "Province1", "Province1", model.Province.ToUpper());
      ViewBag.Regions = new SelectList(_accessPoint.getRegions(), "region1", "region1", model.Region.ToUpper());

      return View(model);
    }

    public ActionResult AccessPointDetail(double uid)
    {
      var model = _accessPoint.getAccessPoint(uid);

      return View(model);
    }

    public JsonResult GetAccessPoints([ModelBinder(typeof(DataTablesBinder))] IDataTablesRequest requestModel)
    {
      IEnumerable<AccessPoint> rawData = null;
      IEnumerable<AccessPoint> searchData = null;
      IEnumerable<AccessPoint> orderData = null;
      IEnumerable<AccessPoint> result = null;

      var saProvince = _accessPoint.getProvinces();

      if (User.IsInRole("Admins"))
      {
        rawData = _accessPoint.getAccessPoints();
      }
      else if (User.IsInRole("ROAUser"))
      {
        rawData = _accessPoint
                  .getAccessPoints()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        rawData = _accessPoint
                 .getAccessPoints()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      if (rawData.Any())
      {
        if (!string.IsNullOrEmpty(requestModel.Search.Value))
        {
          double numSearch = 0;

          string searchString = requestModel.Search.Value;

          if (double.TryParse(searchString, out numSearch))
          {
            searchData = rawData
                        .Where(w => w.MerchantID == numSearch
                        || w.PostalCode.ToString().ToLower().Contains(searchString)
                        || w.Longitude.ToString().ToLower().Contains(searchString)
                        || w.Latitude.ToString().ToLower().Contains(searchString));
          }
          else
          {
            searchData = rawData
                        .Where(w => w.Name.ToLower().Contains(searchString)
                        || (w.Address != null && w.Address.ToLower().Contains(searchString))
                        || (w.Suburb != null && w.Suburb.ToLower().Contains(searchString))
                        || (w.Town != null && w.Town.ToLower().Contains(searchString))
                        || (w.SBSAProvince != null && w.SBSAProvince.ToLower().Contains(searchString))
                        || (w.Region != null && w.Region.ToLower().Contains(searchString))
                        || (w.Province != null && w.Province.ToLower().Contains(searchString)));
          }
        }
        else
        {
          searchData = rawData;
        }

        var sortedColumns = requestModel.Columns.GetSortedColumns();

        foreach (var column in sortedColumns)
        {
          if (column.SortDirection == Column.OrderDirection.Ascendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, false);
          else if (column.SortDirection == Column.OrderDirection.Descendant)
            orderData = searchData
                        .AsQueryable()
                        .DynamicEnumerableOrderBy(column.Data, true);
        }

        result = orderData.Skip(requestModel.Start).Take(requestModel.Length);

        return Json(new DataTablesResponse(requestModel.Draw, result, rawData.Count(), result.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new DataTablesResponse(requestModel.Draw, rawData, rawData.Count(), rawData.Count()), "application/json", JsonRequestBehavior.AllowGet);
      }
    }

    public FileResult AccessPointExcelDownload()
    {
      var fileName = string.Format("Access Point List - {0:dd MMM yy}.xlsx", DateTime.Now);
      var contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

      IEnumerable<AccessPoint> resultSet = null;

      var saProvince = _accessPoint.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _accessPoint.getAccessPoints();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _accessPoint
                  .getAccessPoints()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _accessPoint
                 .getAccessPoints()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      MemoryStream ms = _downloader.DownloadExcelFormat(resultSet, "A:XFD", "A1:XFD1", "A1");

      return File(ms, contentType, fileName);
    }

    public FileResult AccessPointCsvDownload()
    {
      var fileName = string.Format("Access Point List - {0:dd MMM yy}.csv", DateTime.Now);
      var contentType = "text/csv";

      IEnumerable<AccessPoint> resultSet = null;

      var saProvince = _accessPoint.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _accessPoint.getAccessPoints();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _accessPoint
                  .getAccessPoints()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _accessPoint
                 .getAccessPoints()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      byte[] ms = _downloader.DownloadCsvFormat(resultSet);

      return File(ms, contentType, fileName);
    }

  }
}
