﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GeoAdminModels;
using GeoAdminServices;

namespace GeoAdminWeb.Controllers
{
  [Authorize]
  [CustomHandleError]
  public class HomeController : Controller
  {
    private IDashboard _dashboard;

    public HomeController(IDashboard dashboard)
    {
      _dashboard = dashboard;
    }

    public ActionResult Index()
    {
      return View();
    }

    public JsonResult AccessPointChart()
    {
      IEnumerable<AccessPointChartViewModel> resultSet = null;

      var saProvince = _dashboard.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _dashboard.getAccessPointChartData();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _dashboard
                  .getAccessPointChartData()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _dashboard
                 .getAccessPointChartData()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<AccessPointChartViewModel>(), JsonRequestBehavior.AllowGet);
      }

    }

    public JsonResult ATMProvinceChart()
    {
      IEnumerable<ATMProvinceChartViewModel> resultSet = null;

      var saProvince = _dashboard.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _dashboard.getATMProvinceChartData();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _dashboard
                  .getATMProvinceChartData()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _dashboard
                 .getATMProvinceChartData()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.SBSA_PROVINCE)));
      }

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<ATMProvinceChartViewModel>(), JsonRequestBehavior.AllowGet);
      }

    }

    public JsonResult ATMTypeChart()
    {
      IEnumerable<ATMTypeChartViewModel> resultSet = null;

      var saProvince = _dashboard.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _dashboard.getATMTypeChartData();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _dashboard.getROAATMTypeChartData();

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _dashboard.getSAATMTypeChartData();
      }

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<ATMTypeChartViewModel>(), JsonRequestBehavior.AllowGet);
      }
    }

    public JsonResult ATMCentreTypeChart()
    {
      IEnumerable<ATMCentreTypeChartViewModel> resultSet = null;

      var saProvince = _dashboard.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _dashboard.getATMCentreTypeChartData();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _dashboard.getROAATMCentreTypeChartData();

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _dashboard.getSAATMCentreTypeChartData();
      }

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<ATMCentreTypeChartViewModel>(), JsonRequestBehavior.AllowGet);
      }
    }

    public JsonResult BranchChart()
    {
      IEnumerable<BranchChartViewModel> resultSet = null;

      var saProvince = _dashboard.getProvinces();

      if (User.IsInRole("Admins"))
      {
        resultSet = _dashboard.getBranchChartData();
      }
      else if (User.IsInRole("ROAUser"))
      {
        resultSet = _dashboard
                  .getBranchChartData()
                  .Where(w => !saProvince.Any(a => a.Province1.Contains(w.Province)));

      }
      else if (User.IsInRole("SAUser"))
      {
        resultSet = _dashboard
                 .getBranchChartData()
                 .Where(w => saProvince.Any(a => a.Province1.Contains(w.Province)));
      }

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<BranchChartViewModel>(), JsonRequestBehavior.AllowGet);
      }
    }

    public JsonResult PartnerChart()
    {
      IEnumerable<PartnerChartViewModel> resultSet = null;

      resultSet = _dashboard.getPartnerChartData();

      if (resultSet.Any())
      {
        return Json(resultSet, JsonRequestBehavior.AllowGet);
      }
      else
      {
        return Json(new List<BranchChartViewModel>(), JsonRequestBehavior.AllowGet);
      }

    }

  }
}
