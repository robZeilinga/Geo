﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Castle.Windsor;
using Castle.Windsor.Installer;
using Castle.Core.Logging;
using Newtonsoft;
using Newtonsoft.Json;
using GeoAdminWeb.Controllers;
using Castle.Facilities.Logging;

namespace GeoAdminWeb
{
  public class MvcApplication : System.Web.HttpApplication
  {
    private static IWindsorContainer _container;

    protected void Application_Start()
    {
      GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.PreserveReferencesHandling = PreserveReferencesHandling.Objects;
      GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.DateFormatHandling = DateFormatHandling.IsoDateFormat;
      GlobalConfiguration.Configuration.Formatters.JsonFormatter.SerializerSettings.DateParseHandling = DateParseHandling.DateTime;
      GlobalConfiguration.Configuration.Formatters.JsonFormatter.Indent = true;

      AreaRegistration.RegisterAllAreas();

      WebApiConfig.Register(GlobalConfiguration.Configuration);
      FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
      RouteConfig.RegisterRoutes(RouteTable.Routes);
      BundleConfig.RegisterBundles(BundleTable.Bundles);

      BootstrapContainer();
    }

    protected void Application_End()
    {
      _container.Dispose();

    }

    protected void Application_Error(object sender, EventArgs e)
    {
      var httpContext = ((MvcApplication)sender).Context;
      var currentController = " ";
      var currentAction = " ";
      var currentRouteData = RouteTable.Routes.GetRouteData(new HttpContextWrapper(httpContext));

      if (currentRouteData != null)
      {
        if (currentRouteData.Values["controller"] != null && !String.IsNullOrEmpty(currentRouteData.Values["controller"].ToString()))
        {
          currentController = currentRouteData.Values["controller"].ToString();
        }

        if (currentRouteData.Values["action"] != null && !String.IsNullOrEmpty(currentRouteData.Values["action"].ToString()))
        {
          currentAction = currentRouteData.Values["action"].ToString();
        }
      }

      var ex = Server.GetLastError();
      var controller = new ErrorController();
      var routeData = new RouteData();
      var action = "Index";

      if (ex is HttpException)
      {
        var httpEx = ex as HttpException;

        switch (httpEx.GetHttpCode())
        {
          case 400:
            action = "BadRequest";
            break;
          case 404:
            action = "NotFound";
            break;
          case 408:
            action = "RequestTimeout";
            break;
        }
      }

      CastleWindsorHelper.LoggerHelper(ex.Message, ex);

      httpContext.ClearError();
      httpContext.Response.Clear();
      httpContext.Response.StatusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 500;
      httpContext.Response.TrySkipIisCustomErrors = true;

      routeData.Values["controller"] = "Error";
      routeData.Values["action"] = action;

      controller.ViewData.Model = new HandleErrorInfo(ex, currentController, currentAction);
      ((IController)controller).Execute(new RequestContext(new HttpContextWrapper(httpContext), routeData));

    }

    private static void BootstrapContainer()
    {
      _container = new WindsorContainer();
      _container.AddFacility<LoggingFacility>(f => f.UseLog4Net().WithConfig("log4net.config"));
      _container.Install(FromAssembly.This());
      var controllerFactory = new WindsorControllerFactory(_container.Kernel);
      ControllerBuilder.Current.SetControllerFactory(controllerFactory);
    }
  }
}