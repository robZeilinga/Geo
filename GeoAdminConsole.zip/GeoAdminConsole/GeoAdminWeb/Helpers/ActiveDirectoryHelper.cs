﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Principal;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices.Protocols;
using ActiveDs;
using System.Net;
using System.Security;
using GeoAdminModels;
using System.Web.Security;

namespace GeoAdminWeb
{
  public static class ActiveDirectoryHelper
  {
    private static bool _authenticated = false;

    const string _ldap = "GC://";

    public static bool AuthenticateUser(string domainName, string userName, string password, string domainController = "")
    {
      try
      {

        PrincipalContext pc = new PrincipalContext(ContextType.Domain, domainName);

        if (pc.ValidateCredentials(userName, password, ContextOptions.Negotiate))
        {
          _authenticated = true;
        }

        return _authenticated;
      }
      catch (PrincipalException ex)
      {
        return false;
      }
      catch (DirectoryException ex)
      {
        return false;
      }
      catch (Exception ex)
      {
        return false;
      }
    }

    public static ADUserViewModel ADUserInfo(string domainName, string userName, string password,string domainController = "")
    {
      try
      {
        ADUserViewModel model = null;

        DirectoryEntry entry;

        PrincipalContext pContext = new PrincipalContext(ContextType.Domain, domainName,userName,password);

        UserPrincipal uFindUser = new UserPrincipal(pContext);

        uFindUser.SamAccountName = userName;

        PrincipalSearcher pSearcher = new PrincipalSearcher(uFindUser);
                
        UserPrincipal uResult = (UserPrincipal)pSearcher.FindOne();

        pSearcher.Dispose();

        if (uResult != null)
        {
          model = new ADUserViewModel();

          entry = (DirectoryEntry)uResult.GetUnderlyingObject();

          if (entry.Properties["displayName"].Count > 0 && entry.Properties["displayName"][0] != null)
            model.DisplayName = (string)entry.Properties["displayName"][0];
          else
            model.DisplayName = "NULL";

          if (entry.Properties["givenname"].Count > 0 && entry.Properties["givenname"][0] != null)
            model.GivenName = (string)entry.Properties["givenname"][0];
          else
            model.GivenName = "NULL";

          if (entry.Properties["sn"].Count > 0 && entry.Properties["sn"][0] != null)
            model.Sn = (string)entry.Properties["sn"][0];
          else
            model.Sn = "NULL";

          if (entry.Properties["ou"].Count > 0 && entry.Properties["ou"][0] != null)
            model.Ou = (string)entry.Properties["ou"][0];
          else
            model.Ou = "NULL";

          if (entry.Properties["employeeType"].Count > 0 && entry.Properties["employeeType"][0] != null)
            model.EmployeeType = (string)entry.Properties["employeeType"][0];
          else
            model.EmployeeType = "NULL";

          if (entry.Properties["mail"].Count > 0 && entry.Properties["mail"][0] != null)
            model.Mail = (string)entry.Properties["mail"][0];
          else
            model.Mail = "NULL";

          if (entry.Properties["telephoneNumber"].Count > 0 && entry.Properties["telephoneNumber"][0] != null)
            model.TelephoneNumber = (string)entry.Properties["telephoneNumber"][0];
          else
            model.TelephoneNumber = "NULL";

          if (entry.Properties["samAccountName"].Count > 0 && entry.Properties["samAccountName"][0] != null)
            model.SamAccountName = (string)entry.Properties["samAccountName"][0];
          else
            model.SamAccountName = "NULL";

          if (entry.Properties["c"].Count > 0 && entry.Properties["c"][0] != null)
            model.C = (string)entry.Properties["c"][0];
          else
            model.C = "NULL";

        }

        return model;
      }
      catch (DirectoryException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static ADUserViewModel ADLoadUserInfo(string domainName, string userName, string password, string samAccountName)
    {
      try
      {
        ADUserViewModel model = null;

        DirectoryEntry entry;

        PrincipalContext pContext = new PrincipalContext(ContextType.Domain, domainName, userName, password);

        UserPrincipal uFindUser = new UserPrincipal(pContext);

        uFindUser.SamAccountName = samAccountName;       

        PrincipalSearcher pSearcher = new PrincipalSearcher(uFindUser);

        UserPrincipal uResult = (UserPrincipal)pSearcher.FindOne();

        pSearcher.Dispose();

        if (uResult != null)
        {
          model = new ADUserViewModel();

          entry = (DirectoryEntry)uResult.GetUnderlyingObject();

          if (entry.Properties["displayName"].Count > 0 && entry.Properties["displayName"][0] != null)
            model.DisplayName = (string)entry.Properties["displayName"][0];
          else
            model.DisplayName = "NULL";

          if (entry.Properties["givenname"].Count > 0 && entry.Properties["givenname"][0] != null)
            model.GivenName = (string)entry.Properties["givenname"][0];
          else
            model.GivenName = "NULL";

          if (entry.Properties["sn"].Count > 0 && entry.Properties["sn"][0] != null)
            model.Sn = (string)entry.Properties["sn"][0];
          else
            model.Sn = "NULL";

          if (entry.Properties["ou"].Count > 0 && entry.Properties["ou"][0] != null)
            model.Ou = (string)entry.Properties["ou"][0];
          else
            model.Ou = "NULL";

          if (entry.Properties["employeeType"].Count > 0 && entry.Properties["employeeType"][0] != null)
            model.EmployeeType = (string)entry.Properties["employeeType"][0];
          else
            model.EmployeeType = "NULL";

          if (entry.Properties["mail"].Count > 0 && entry.Properties["mail"][0] != null)
            model.Mail = (string)entry.Properties["mail"][0];
          else
            model.Mail = "NULL";

          if (entry.Properties["telephoneNumber"].Count > 0 && entry.Properties["telephoneNumber"][0] != null)
            model.TelephoneNumber = (string)entry.Properties["telephoneNumber"][0];
          else
            model.TelephoneNumber = "NULL";

          if (entry.Properties["samAccountName"].Count > 0 && entry.Properties["samAccountName"][0] != null)
            model.SamAccountName = (string)entry.Properties["samAccountName"][0];
          else
            model.SamAccountName = "NULL";

          if (entry.Properties["c"].Count > 0 && entry.Properties["c"][0] != null)
            model.C = (string)entry.Properties["c"][0];
          else
            model.C = "NULL";

        }

        return model;
      }
      catch (DirectoryException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static List<ADUserViewModel> SearchActiveDirectoryUsers(string domainName,string userName,string password, string sUserName = "", string sDisplayName = "", string sEmail = "")
    {
      List<ADUserViewModel> lstActiveDirectoryUsers = new List<ADUserViewModel>();

      try
      {
        ADUserViewModel model = null;

        DirectoryEntry entry;

        PrincipalContext pContext = new PrincipalContext(ContextType.Domain, domainName, userName, password);

        UserPrincipal uFindUser = new UserPrincipal(pContext);

        if (!string.IsNullOrEmpty(sUserName))
          uFindUser.SamAccountName = string.Format("{0}*", sUserName);

        if (!string.IsNullOrEmpty(sDisplayName))
          uFindUser.DisplayName = string.Format("{0}*", sDisplayName);

        if (!string.IsNullOrEmpty(sEmail))
          uFindUser.EmailAddress = string.Format("{0}*", sEmail);

        PrincipalSearcher pSearcher = new PrincipalSearcher(uFindUser);

        PrincipalSearchResult<Principal> uResult = pSearcher.FindAll();

        pSearcher.Dispose();

        if (uResult != null)
        {
          foreach (Principal result in uResult)
          {
            model = new ADUserViewModel();

            entry = (DirectoryEntry)result.GetUnderlyingObject();

            if (entry.Properties["displayName"].Count > 0 && entry.Properties["displayName"][0] != null)
              model.DisplayName = (string)entry.Properties["displayName"][0];
            else
              model.DisplayName = "NULL";

            if (entry.Properties["givenname"].Count > 0 && entry.Properties["givenname"][0] != null)
              model.GivenName = (string)entry.Properties["givenname"][0];
            else
              model.GivenName = "NULL";

            if (entry.Properties["sn"].Count > 0 && entry.Properties["sn"][0] != null)
              model.Sn = (string)entry.Properties["sn"][0];
            else
              model.Sn = "NULL";

            if (entry.Properties["ou"].Count > 0 && entry.Properties["ou"][0] != null)
              model.Ou = (string)entry.Properties["ou"][0];
            else
              model.Ou = "NULL";

            if (entry.Properties["employeeType"].Count > 0 && entry.Properties["employeeType"][0] != null)
              model.EmployeeType = (string)entry.Properties["employeeType"][0];
            else
              model.EmployeeType = "NULL";

            if (entry.Properties["mail"].Count > 0 && entry.Properties["mail"][0] != null)
              model.Mail = (string)entry.Properties["mail"][0];
            else
              model.Mail = "NULL";

            if (entry.Properties["telephoneNumber"].Count > 0 && entry.Properties["telephoneNumber"][0] != null)
              model.TelephoneNumber = (string)entry.Properties["telephoneNumber"][0];
            else
              model.TelephoneNumber = "NULL";

            if (entry.Properties["samAccountName"].Count > 0 && entry.Properties["samAccountName"][0] != null)
              model.SamAccountName = (string)entry.Properties["samAccountName"][0];
            else
              model.SamAccountName = "NULL";

            if (entry.Properties["c"].Count > 0 && entry.Properties["c"][0] != null)
              model.C = (string)entry.Properties["c"][0];
            else
              model.C = "NULL";

            lstActiveDirectoryUsers.Add(model);
          }
        }

        return lstActiveDirectoryUsers;
      }
      catch (DirectoryException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    private static string getActiveDirectoryDN(string domainName, string userName)
    {
      try
      {
        string activeDirectoryDN = "";

        NameTranslate translate = new NameTranslate();

        string domainAndUser = string.Concat(domainName, @"\", userName);

        translate.Set(8, domainAndUser);

        activeDirectoryDN = translate.Get(1);

        return activeDirectoryDN;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }
  }
}