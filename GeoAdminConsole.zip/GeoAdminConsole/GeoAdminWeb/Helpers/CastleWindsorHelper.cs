﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Castle.Windsor;
using Castle.Windsor.Installer;
using Castle.Core.Logging;
using Castle.Facilities.Logging;

namespace GeoAdminWeb
{
  public static class CastleWindsorHelper
  {
    private static IWindsorContainer _container;

    public static void LoggerHelper(string message, Exception ex)
    {
      _container = new WindsorContainer();

      _container.AddFacility<LoggingFacility>(f => f.UseLog4Net().WithConfig("log4net.config"));

      var logger = _container.Resolve<ILogger>();

      logger.Error(ex.Message, ex);

      _container.Release(logger);
    }
  }
}