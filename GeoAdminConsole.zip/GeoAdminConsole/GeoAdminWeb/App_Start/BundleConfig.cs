﻿using System.Web;
using System.Web.Optimization;

namespace GeoAdminWeb
{
  public class BundleConfig
  {
    // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
    public static void RegisterBundles(BundleCollection bundles)
    {
      // CSS style (bootstrap/Geo Admin Console)
      bundles.Add(new StyleBundle("~/Content/css").Include(                  
                  "~/Content/bootstrap.css",
                  "~/Content/plugins/metis/metisMenu.css",
                  "~/Content/sb-admin-2.css"));

      // jQuery
      bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                  "~/Scripts/jquery-2.1.1.js"));

      // Bootstrap
      bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Scripts/bootstrap.js"));

      //Pace
      bundles.Add(new ScriptBundle("~/bundles/pace").Include(
                "~/Scripts/plugins/pace/pace.js"));

      bundles.Add(new StyleBundle("~/bundles/paceStyle").Include(
                  "~/Content/plugins/pace/themes/blue/pace-theme-loading-bar.css"));

      // jQueryUI CSS
      bundles.Add(new StyleBundle("~/bundles/jqueryuiStyles").Include(
                  "~/Content/plugins/jqueryui/jquery-ui.css"));

      // jQueryUI 
      bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                  "~/Scripts/plugins/jqueryui/jquery-ui-1.8.20.js"));

      // Geo Admin script
      bundles.Add(new ScriptBundle("~/bundles/geoadmin").Include(
                "~/Scripts/plugins/metis/metisMenu.js",
                "~/Scripts/app/sb-admin-2.js"));

      // dataTables css styles
      bundles.Add(new StyleBundle("~/plugins/dataTablesStyles").Include(
                "~/Content/plugins/datatables/dataTables.bootstrap.css",
                "~/Content/plugins/datatables/dataTables.responsive.css",
                "~/Content/plugins/datatables/dataTables.tableTools.css"));

      // dataTables scripts
      bundles.Add(new ScriptBundle("~/plugins/dataTables").Include(
                "~/Scripts/plugins/datatables/jquery.dataTables.js",
                "~/Scripts/plugins/datatables/dataTables.bootstrap.js",
                "~/Scripts/plugins/datatables/dataTables.responsive.js",
                "~/Scripts/plugins/datatables/dataTables.tableTools.js"));

      // validate 
      bundles.Add(new ScriptBundle("~/plugins/validate").Include(
                "~/Scripts/plugins/validate/jquery.validate.js",
                "~/Scripts/plugins/validate/jquery.validate.unobtrusive.js",
                "~/Scripts/plugins/validate/jquery.validate.unobtrusive.bootstrap.js"));

      // fullCalendar 
      bundles.Add(new ScriptBundle("~/plugins/calender").Include(
                "~/Scripts/plugins/moment/moment.js"));

      // Mustache
      bundles.Add(new ScriptBundle("~/bundles/mustache").Include(
                "~/Scripts/plugins/mustache/mustache.js"));


      // Use the development version of Modernizr to develop with and learn from. Then, when you're
      // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
      bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                  "~/Scripts/plugins/modernizr/modernizr-2.8.3.js"));

      /// Morris chart
      bundles.Add(new ScriptBundle("~/bundles/morris").Include(
                  "~/Scripts/plugins/raphael/raphael.js",
                  "~/Scripts/plugins/morris/morris.js"));

      // Morris css styles
      bundles.Add(new StyleBundle("~/bundles/morrisStyle").Include(
            "~/Content/plugins/morris/morris.css"));

      BundleTable.EnableOptimizations = false;

    }
  }
}