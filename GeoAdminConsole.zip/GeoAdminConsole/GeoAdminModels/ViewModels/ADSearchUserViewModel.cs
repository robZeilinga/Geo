﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class ADSearchUserViewModel
  {
    public string SearchField { get; set; }

    public string SearchValue { get; set; }

  }
}
