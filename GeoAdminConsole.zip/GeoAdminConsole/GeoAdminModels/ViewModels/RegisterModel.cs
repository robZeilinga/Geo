﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace GeoAdminModels
{
  public class RegisterModel
  {
    [Required]
    [RegularExpression(@"[aA|cC]\d{5,}",ErrorMessage = "User name must start with A or C and have a minimum 5 digits.")]
    [Display(Name = "User name")]
    public string UserName { get; set; }

    [Required]
    [Display(Name = "User Role")]
    public string RoleName { get; set; }

    [Required]
    [Display(Name = "Domain")]
    public string DomainName { get; set; }
  }
}
