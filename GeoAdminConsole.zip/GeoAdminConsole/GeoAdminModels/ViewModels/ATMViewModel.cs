﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class ATMViewModel : BaseAudit
  {
    #region ATMViewModel Members

    #endregion

    #region ATMViewModel Ctor

    public ATMViewModel()
    {
    }

    public ATMViewModel(DateTime modifiedDate, string modifiedUser)
      : base(modifiedDate, modifiedUser)
    {
    }

    #endregion

    #region ATMViewModel Properties

    [Display(Name = "SBSA Province")]
    [Required]
    [StringLength(255)]
    public string SBSA_PROVINCE { get; set; }

    [Display(Name = "SBSA Region")]
    [Required]
    [StringLength(255)]
    public string SBSA_REGION { get; set; }

    [Display(Name = "Site Name")]
    [Required]
    [StringLength(255)]
    public string SITE_NAME { get; set; }

    [Display(Name = "ATM Name")]
    [Required]
    [StringLength(255)]
    public string ATM_NAME { get; set; }

    [Display(Name = "CICS ID")]
    [Required]
    [StringLength(255)]
    public string CICS_ID { get; set; }

    [Display(Name = "Installation Date")]
    public Nullable<double> INSTALLATION_DATE { get; set; }

    [Display(Name = "Address 1")]
    [StringLength(255)]
    public string ADDRESS1 { get; set; }

    [Display(Name = "Address 2")]
    [StringLength(255)]
    public string ADDRESS2 { get; set; }

    [Display(Name = "Address 3")]
    [StringLength(255)]
    public string ADDRESS3 { get; set; }

    [Display(Name = "Address 4")]
    [StringLength(255)]
    public string ADDRESS4 { get; set; }

    [Display(Name = "Address 5")]
    [StringLength(255)]
    public string ADDRESS5 { get; set; }

    [Display(Name = "Address 6")]
    [StringLength(255)]
    public string ADDRESS6 { get; set; }

    [Display(Name = "Address 7")]
    [StringLength(255)]
    public string ADDRESS7 { get; set; }

    [Display(Name = "ATM Ownership")]
    [StringLength(255)]
    public string ATM_OWNERSHIP { get; set; }

    [Display(Name = "ATM Type")]
    [Required]
    [StringLength(255)]
    public string ATM_TYPE { get; set; }

    [Display(Name = "ATM Class")]
    [Required]
    [StringLength(255)]
    public string ATM_CLASS { get; set; }

    [Display(Name = "Centre Type")]
    [StringLength(255)]
    public string CENTRE_TYPE { get; set; }

    [Display(Name = "Centre Name")]
    [StringLength(255)]
    public string CENTRE_NAME { get; set; }

    [Display(Name = "Centre No")]
    public Nullable<double> CENTRE_NO { get; set; }

    [Display(Name = "Open To Public")]
    [StringLength(255)]
    public string OPEN_TO_PUBLIC { get; set; }

    [Display(Name = "Longitude")]
    [Required]
    public double LONGITUDE { get; set; }

    [Display(Name = "Latitude")]
    [Required]
    public double LATITUDE { get; set; }

    #endregion

  }
}
