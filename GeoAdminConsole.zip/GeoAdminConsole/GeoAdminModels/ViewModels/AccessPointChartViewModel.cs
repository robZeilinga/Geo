﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class AccessPointChartViewModel
  {
    public string Province { get; set; }
    public int Count { get; set; }
  }
}
