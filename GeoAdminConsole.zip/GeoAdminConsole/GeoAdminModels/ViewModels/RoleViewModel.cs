﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class RoleViewModel
  {
    [Required]
    [Display(Name = "Role Name")]
    [StringLength(255)]
    public string RoleName { get; set; }
  }
}
