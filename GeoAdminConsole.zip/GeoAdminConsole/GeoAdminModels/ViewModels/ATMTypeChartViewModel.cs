﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class ATMTypeChartViewModel
  {
    public string ATM_TYPE { get; set; }
    public int Count { get; set; }
  }
}
