﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class PartnerViewModel : BaseAudit
  {
    #region PartnerViewModel Members

    #endregion

    #region PartnerViewModel Ctor

    public PartnerViewModel()
    {
    }

    public PartnerViewModel(DateTime modifiedDate, string modifiedUser)
      : base(modifiedDate, modifiedUser)
    {
    }

    #endregion

    #region PartnerViewModel Properties

    [Display(Name = "Partner ID")]
    [Required]
    [StringLength(50)]
    public string PartnerID { get; set; }

    [Display(Name = "Partner Name")]
    [Required]
    [StringLength(50)]
    public string PartnerName { get; set; }

    [Display(Name = "Country")]
    [Required]
    [StringLength(50)]
    public string Country { get; set; }

    [Display(Name = "Name")]
    [Required]
    [StringLength(255)]
    public string Name { get; set; }

    [Display(Name = "Address 1")]
    [StringLength(255)]
    public string Address1 { get; set; }

    [Display(Name = "Address 2")]
    [StringLength(255)]
    public string Address2 { get; set; }

    [Display(Name = "Suburb")]
    [StringLength(255)]
    public string Suburb { get; set; }

    [Display(Name = "Town")]
    [StringLength(255)]
    public string Town { get; set; }

    [Display(Name = "Postal Code")]
    public Nullable<int> PostCode { get; set; }

    [Display(Name = "Province")]
    [Required]
    [StringLength(255)]
    public string Province { get; set; }

    [Display(Name = "Latitude")]
    [Required]
    public double Latitude { get; set; }

    [Display(Name = "Longitude")]
    [Required]
    public double Longitude { get; set; }

    #endregion

  }
}
