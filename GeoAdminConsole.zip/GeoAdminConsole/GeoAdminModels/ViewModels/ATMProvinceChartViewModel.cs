﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class ATMProvinceChartViewModel
  {
    public string SBSA_PROVINCE { get; set; }
    public int Count { get; set; }
  }
}
