﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class LogOnModel
  {
    [Required]
    [RegularExpression(@"[aA|cC]\d{5,}", ErrorMessage = "User name must start with A or C and have a minimum 5 digits.")]
    [Display(Name = "User name")]
    public string UserName { get; set; }

    [Required]
    [DataType(DataType.Password)]
    [Display(Name = "Password")]
    public string Password { get; set; }

    [Display(Name = "Domain")]
    public string DomainName { get; set; }
  }
}
