﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class AccessPointViewModel : BaseAudit
  {
    #region AccessPointViewModel Members

    #endregion

    #region AccessPointViewModel Ctor

    public AccessPointViewModel()
    {
    }

    public AccessPointViewModel(DateTime modifiedDate, string modifiedUser)
      : base(modifiedDate, modifiedUser)
    {
    }

    #endregion

    #region AccessPointViewModel Properties

    [Display(Name = "Merchant ID")]
    [Required]
    public double MerchantID { get; set; }

    [Display(Name = "Name")]
    [Required]
    [StringLength(255)]
    public string Name { get; set; }

    [Display(Name = "Address")]
    [Required]
    [StringLength(255)]
    public string Address { get; set; }

    [Display(Name = "Suburb")]
    [Required]
    [StringLength(255)]
    public string Suburb { get; set; }

    [Display(Name = "Town")]
    [StringLength(255)]
    public string Town { get; set; }

    [Display(Name = "SBSA Province")]
    [Required]
    [StringLength(255)]
    public string SBSAProvince { get; set; }

    [Display(Name = "Region")]
    [StringLength(255)]
    public string Region { get; set; }

    [Display(Name = "Postal Code")]
    [Required]
    public double PostalCode { get; set; }

    [Display(Name = "Province")]
    [Required]
    [StringLength(255)]
    public string Province { get; set; }

    [Display(Name = "Longitude")]
    [Required]
    public double Longitude { get; set; }

    [Display(Name = "Latitude")]
    [Required]
    public double Latitude { get; set; }

    #endregion

  }
}
