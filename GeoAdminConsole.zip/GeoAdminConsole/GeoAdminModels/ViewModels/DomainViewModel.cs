﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class DomainViewModel
  {
    public string DomainLongName { get; set; }

    public string DomainShortName { get; set; }

    public bool Selected { get; set; }
  }
}
