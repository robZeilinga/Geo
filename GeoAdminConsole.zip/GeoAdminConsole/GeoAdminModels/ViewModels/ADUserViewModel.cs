﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public class ADUserViewModel
  {
    public string UserName { get; set; }
    public string DisplayName { get; set; }
    public string GivenName { get; set; }
    public string Sn { get; set; }
    public string Ou { get; set; }
    public string EmployeeType { get; set; }
    public string Mail { get; set; }
    public string TelephoneNumber { get; set; }
    public string SamAccountName { get; set; }
    public string C { get; set; }
    public string RoleName { get; set; }
  }
}
