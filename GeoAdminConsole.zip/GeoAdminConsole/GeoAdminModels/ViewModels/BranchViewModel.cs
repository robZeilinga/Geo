﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace GeoAdminModels
{
  public class BranchViewModel : BaseAudit
  {
    #region BranchViewModel Members

    #endregion

    #region BranchViewModel Ctor

    public BranchViewModel()
    {
    }

    public BranchViewModel(DateTime modifiedDate, string modifiedUser)
      : base(modifiedDate, modifiedUser)
    {
    }

    #endregion

    #region BranchViewModel Properties

    [Display(Name = "Branch Code")]
    [Required]
    public double BranchCode { get; set; }

    [Display(Name = "Name")]
    [Required]
    [StringLength(255)]
    public string Name { get; set; }

    [Display(Name = "Type")]
    [Required]
    [StringLength(255)]
    public string Type { get; set; }

    [Display(Name = "Shop Number")]
    [StringLength(255)]
    public string ShopNumber { get; set; }

    [Display(Name = "Building Name")]
    [StringLength(255)]
    public string BuildingName { get; set; }

    [Display(Name = "Street")]
    [StringLength(255)]
    public string Street { get; set; }

    [Display(Name = "Suburb")]
    [StringLength(255)]
    public string Suburb { get; set; }

    [Display(Name = "Town")]
    [StringLength(255)]
    public string Town { get; set; }

    [Display(Name = "Province")]
    [Required]
    [StringLength(255)]
    public string Province { get; set; }

    [Display(Name = "Latitude")]
    [Required]
    public double Latitude { get; set; }

    [Display(Name = "Longitude")]
    [Required]
    public double Longitude { get; set; }

    #endregion

  }
}
