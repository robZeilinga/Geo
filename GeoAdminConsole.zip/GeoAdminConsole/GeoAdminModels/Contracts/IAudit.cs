﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public interface IAudit
  {
    DateTime modified_date { get; set; }
    string modified_by { get; set; }
  }
}
