﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeoAdminModels
{
  public abstract class BaseAudit : IAudit
  {
    private DateTime _dateModified;
    private string _userModified;

    public BaseAudit()
    {
    }

    public BaseAudit(DateTime modifiedDate, string modifiedUser)
    {
      this.modified_date = modifiedDate;
      this.modified_by = modifiedUser;
    }

    public virtual DateTime modified_date
    {
      get
      {
        return _dateModified;
      }
      set
      {
        _dateModified = value;
      }
    }

    public virtual string modified_by
    {
      get
      {
        return _userModified;
      }
      set
      {
        _userModified = value;
      }
    }
  }
}
