using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class Centre
    {
        public double BranchCode { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string ShopNumber { get; set; }
        public string BuildingName { get; set; }
        public string Street { get; set; }
        public string Suburb { get; set; }
        public string Town { get; set; }
        public string Province { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
