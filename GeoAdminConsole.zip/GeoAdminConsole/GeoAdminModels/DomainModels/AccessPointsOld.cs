using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class AccessPointsOld
    {
        public double ID { get; set; }
        public double RetailerID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Suburb { get; set; }
        public string Town { get; set; }
        public string Province { get; set; }
        public double PostalCode { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public string Batch { get; set; }
    }
}
