using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class Region
    {
        public int Id { get; set; }
        public string region1 { get; set; }
    }
}
