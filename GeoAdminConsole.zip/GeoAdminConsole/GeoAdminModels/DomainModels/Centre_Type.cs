using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class Centre_Type
    {
        public int Id { get; set; }
        public string CentreType { get; set; }
    }
}
