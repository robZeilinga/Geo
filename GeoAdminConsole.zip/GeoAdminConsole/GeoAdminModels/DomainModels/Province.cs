using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class Province
    {
        public int Id { get; set; }
        public string Province1 { get; set; }
    }
}
