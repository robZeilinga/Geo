using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class POI
    {
        public string id { get; set; }
        public string attribution { get; set; }
        public string title { get; set; }
        public decimal lat { get; set; }
        public decimal lon { get; set; }
        public string imageURL { get; set; }
        public string line4 { get; set; }
        public string line3 { get; set; }
        public string line2 { get; set; }
        public Nullable<int> type { get; set; }
        public Nullable<int> dimension { get; set; }
        public Nullable<int> alt { get; set; }
        public Nullable<int> relativeAlt { get; set; }
        public decimal distance { get; set; }
        public Nullable<byte> inFocus { get; set; }
        public Nullable<byte> doNotIndex { get; set; }
        public Nullable<byte> showSmallBiw { get; set; }
        public Nullable<byte> showBiwOnClick { get; set; }
    }
}
