using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class ATM_Type
    {
        public int Id { get; set; }
        public string ATMType { get; set; }
        public string Model { get; set; }
    }
}
