using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class vw_aspnet_WebPartState_User
    {
        public Nullable<System.Guid> PathId { get; set; }
        public Nullable<System.Guid> UserId { get; set; }
        public Nullable<int> DataSize { get; set; }
        public System.DateTime LastUpdatedDate { get; set; }
    }
}
