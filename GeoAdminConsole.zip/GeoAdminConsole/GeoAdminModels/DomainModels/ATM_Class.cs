using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class ATM_Class
    {
        public int Id { get; set; }
        public string ATMClass { get; set; }
    }
}
