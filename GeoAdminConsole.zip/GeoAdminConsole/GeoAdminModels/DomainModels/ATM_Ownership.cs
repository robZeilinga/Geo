using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class ATM_Ownership
    {
        public int Id { get; set; }
        public string ATMOwnership { get; set; }
    }
}
