using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class vw_aspnet_WebPartState_Paths
    {
        public System.Guid ApplicationId { get; set; }
        public System.Guid PathId { get; set; }
        public string Path { get; set; }
        public string LoweredPath { get; set; }
    }
}
