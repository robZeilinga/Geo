using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class AccessPoint
    {
        public double MerchantID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Suburb { get; set; }
        public string Town { get; set; }
        public string SBSAProvince { get; set; }
        public string Region { get; set; }
        public double PostalCode { get; set; }
        public string Province { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
