using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class PartnersNew
    {
        public string PartnerID { get; set; }
        public string PartnerName { get; set; }
        public string Country { get; set; }
        public string Name { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Suburb { get; set; }
        public string Town { get; set; }
        public Nullable<int> PostCode { get; set; }
        public string Province { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
