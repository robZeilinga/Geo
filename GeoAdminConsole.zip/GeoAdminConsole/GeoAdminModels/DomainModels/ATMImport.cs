using System;
using System.Collections.Generic;

namespace GeoAdminModels
{
    public partial class ATMImport
    {
        public string SBSA_PROVINCE { get; set; }
        public string SBSA_REGION { get; set; }
        public string SITE_NAME { get; set; }
        public string ATM_NAME { get; set; }
        public string CICS_ID { get; set; }
        public Nullable<double> INSTALLATION_DATE { get; set; }
        public string ADDRESS1 { get; set; }
        public string ADDRESS2 { get; set; }
        public string ADDRESS3 { get; set; }
        public string ADDRESS4 { get; set; }
        public string ADDRESS5 { get; set; }
        public string ADDRESS6 { get; set; }
        public string ADDRESS7 { get; set; }
        public string ATM_OWNERSHIP { get; set; }
        public string ATM_TYPE { get; set; }
        public string ATM_CLASS { get; set; }
        public string CENTRE_TYPE { get; set; }
        public string CENTRE_NAME { get; set; }
        public Nullable<double> CENTRE_NO { get; set; }
        public string OPEN_TO_PUBLIC { get; set; }
        public double LONGITUDE { get; set; }
        public double LATITUDE { get; set; }
    }
}
